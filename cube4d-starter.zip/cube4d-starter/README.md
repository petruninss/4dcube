# 4ДКУБ — внутренний уровень услуг / prototype

Тестовая версия механики двухуровневого куба.

## Что проверить
1. Открыть грань «Услуги».
2. Выбрать одну из 6 услуг в появившемся списке.
3. Камера проходит через грань внутрь куба и разворачивается на 180°.
4. Внутри доступны 6 внутренних граней услуг через кнопки 01–06.
5. Кнопка «← НАРУЖУ» возвращает на внешнюю грань «Услуги».

Сохранены процедурные фоны и временный переключатель фонов. Постоянного render loop нет.

## 4ДКУБ ADMIN

В версии v6 добавлена простая PHP+JSON админка для текстов и портфолио. Подробности: `ADMIN_SETUP.md`.

## V7 inner-projects layout
- Project cards inside the Projects cube are square and more compact.
- The Back button is placed at the bottom center instead of the old 01-06 control.
- Inner face navigation is moved to the left column and uses face names.
- The left hero title inside Projects remains "ПРОЕКТЫ" instead of changing to the active category.
- Side faces inside the cube do not show distracting labels; Projects uses clean faces around the gallery.
