import { mkdir } from 'node:fs/promises'
import { join } from 'node:path'
const outputDir = join(process.cwd(), 'public', 'radiant')
await mkdir(outputDir, { recursive: true })
console.log('radiant sync skipped: legacy face effects removed in v10.11.0')
