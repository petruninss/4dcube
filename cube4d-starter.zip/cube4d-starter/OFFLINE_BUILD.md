# 4ДКУБ v10.9.3 — Offline build

This project does not use a runtime CDN for Three.js in the production build.

## Build
1. Run `npm ci` (or `npm install`) on the build machine.
2. Run `npm run build`.
3. Upload the contents of `dist/` to the web root.

Vite bundles the installed `three` package into the generated JavaScript assets, so the deployed site does not request Three.js from jsDelivr, unpkg, or another CDN.

Google Fonts remain optional external resources when one of the Google font presets is selected in Admin. Local font packaging can be done separately after the final font set is chosen.
