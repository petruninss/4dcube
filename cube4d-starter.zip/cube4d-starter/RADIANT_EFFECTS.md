# Original Radiant effects

V10.9.7 uses the original self-contained effect source files from Paul Bakaus' Radiant project (MIT):

- Services -> flow-field.html
- Projects -> phyllotaxis.html
- Company -> vertigo.html
- Laboratory -> digital-rain.html
- Shop -> kinetic-grid.html
- Contacts -> strange-attractor.html

Run `npm run sync:radiant` to vendor the exact current upstream HTML files into `public/radiant/`.
`npm run build` runs the sync automatically and then builds the site. Runtime uses only the local copies.

Implementation detail: only the currently selected section creates a hidden same-origin iframe. Its original canvas is used as a `THREE.CanvasTexture` on the selected physical cube face. When the section is left, the iframe and texture are destroyed, so all six original effects never run simultaneously.
