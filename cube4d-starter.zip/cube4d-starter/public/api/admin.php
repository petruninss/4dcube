<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

session_name('cube4d_admin');
session_set_cookie_params([
    'httponly' => true,
    'samesite' => 'Strict',
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
]);
session_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

const MAX_UPLOAD_BYTES = 15728640; // 15 MB

$root = dirname(__DIR__);
$dataDir = $root . '/data';
$uploadDir = $root . '/projects/uploads';
$configFile = __DIR__ . '/config.local.php';
$contentFile = $dataDir . '/content.json';
$projectsFile = $dataDir . '/projects.json';

function respond(array $payload, int $status = 200) {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function action(): string {
    return isset($_GET['action']) ? (string)$_GET['action'] : 'status';
}

function configured(string $configFile): bool {
    return is_file($configFile);
}

function config(string $configFile): array {
    if (!is_file($configFile)) return [];
    $cfg = require $configFile;
    return is_array($cfg) ? $cfg : [];
}

function ensureCsrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return (string)$_SESSION['csrf'];
}

function requireAuth(): void {
    if (empty($_SESSION['admin'])) respond(['ok' => false, 'error' => 'AUTH_REQUIRED'], 401);
}

function requireCsrf(): void {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!$token || empty($_SESSION['csrf']) || !hash_equals((string)$_SESSION['csrf'], (string)$token)) {
        respond(['ok' => false, 'error' => 'CSRF'], 403);
    }
}

function readJsonBody(): array {
    $raw = (string)file_get_contents('php://input');
    $contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));

    // Shared hostings/WAFs sometimes reject JSON POST bodies. The admin therefore
    // also supports a classic form field named `payload` containing JSON.
    if (strpos($contentType, 'application/x-www-form-urlencoded') !== false) {
        $payload = isset($_POST['payload']) ? (string)$_POST['payload'] : '';
        if ($payload === '' && $raw !== '') {
            parse_str($raw, $parsed);
            $payload = isset($parsed['payload']) ? (string)$parsed['payload'] : '';
        }
        $raw = $payload;
    }

    $data = json_decode($raw !== '' ? $raw : '{}', true);
    if (!is_array($data)) {
        respond([
            'ok' => false,
            'error' => 'INVALID_JSON',
            'json_error' => function_exists('json_last_error_msg') ? json_last_error_msg() : (string)json_last_error(),
        ], 400);
    }
    return $data;
}

function writeJsonAtomic(string $file, $data): void {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) respond(['ok' => false, 'error' => 'ENCODE_FAILED'], 500);

    $payload = $json . "\n";
    $dir = dirname($file);
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0775, true) && !is_dir($dir)) {
            respond(['ok' => false, 'error' => 'WRITE_FAILED', 'hint' => 'Не удалось создать папку data/'], 500);
        }
    }

    // Prefer writing the existing file in-place. This is the most compatible
    // method on shared hosting where rename() or temp files can be restricted.
    $handle = @fopen($file, 'c+b');
    if ($handle !== false) {
        $locked = @flock($handle, LOCK_EX);
        if ($locked) {
            @rewind($handle);
            @ftruncate($handle, 0);
            $written = @fwrite($handle, $payload);
            @fflush($handle);
            @flock($handle, LOCK_UN);
            @fclose($handle);
            if ($written !== false && $written === strlen($payload)) return;
        } else {
            @fclose($handle);
        }
    }

    // Fallback for hostings where fopen/flock behaves differently.
    if (@file_put_contents($file, $payload, LOCK_EX) !== false) return;

    respond([
        'ok' => false,
        'error' => 'WRITE_FAILED',
        'hint' => 'PHP не может записать файл ' . basename($file) . '. Проверь права владельца/записи на public/data.',
        'file_exists' => is_file($file),
        'file_writable' => is_file($file) ? is_writable($file) : null,
        'dir_writable' => is_writable($dir),
    ], 500);
}


function cleanProjectMedia($media, string $legacyImage = '', string $title = ''): array {
    $clean = [];
    if (is_array($media)) {
        foreach ($media as $index => $entry) {
            if (is_string($entry)) $entry = ['src' => $entry];
            if (!is_array($entry)) continue;
            $src = substr(trim((string)($entry['src'] ?? $entry['path'] ?? $entry['url'] ?? '')), 0, 500);
            if ($src === '') continue;
            $type = strtolower((string)($entry['type'] ?? '')) === 'video' || preg_match('/\.(mp4|webm)(?:\?|#|$)/i', $src) ? 'video' : 'image';
            $id = preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string)($entry['id'] ?? ''));
            if (!$id) $id = 'media-' . substr(hash('sha256', $src . '|' . $index), 0, 12);
            $clean[] = [
                'id' => $id,
                'src' => $src,
                'type' => $type,
                'cover' => !empty($entry['cover']),
                'alt' => substr(trim((string)($entry['alt'] ?? $title)), 0, 300),
            ];
        }
    }
    if (!$clean && trim($legacyImage) !== '') {
        $src = substr(trim($legacyImage), 0, 500);
        $clean[] = [
            'id' => 'legacy-cover',
            'src' => $src,
            'type' => preg_match('/\.(mp4|webm)(?:\?|#|$)/i', $src) ? 'video' : 'image',
            'cover' => true,
            'alt' => substr(trim($title), 0, 300),
        ];
    }
    $coverSeen = false;
    foreach ($clean as &$entry) {
        if ($entry['cover'] && !$coverSeen) $coverSeen = true;
        elseif ($entry['cover']) $entry['cover'] = false;
    }
    unset($entry);
    if ($clean && !$coverSeen) $clean[0]['cover'] = true;
    return array_values($clean);
}

function projectCoverFromMedia(array $media, string $fallback = ''): string {
    foreach ($media as $entry) if (!empty($entry['cover']) && !empty($entry['src'])) return (string)$entry['src'];
    if (!empty($media[0]['src'])) return (string)$media[0]['src'];
    return $fallback;
}

function saveUploadedMediaFile(array $file, string $uploadDir): array {
    if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) respond(['ok' => false, 'error' => 'NO_FILE'], 400);
    if ((int)($file['size'] ?? 0) > MAX_UPLOAD_BYTES) respond(['ok' => false, 'error' => 'FILE_TOO_LARGE'], 413);
    $mime = '';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = (string)$finfo->file($file['tmp_name']);
    } elseif (function_exists('mime_content_type')) {
        $mime = (string)@mime_content_type($file['tmp_name']);
    }
    $allowed = [
        'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif',
        'video/mp4' => 'mp4', 'video/webm' => 'webm',
    ];
    $ext = $allowed[$mime] ?? null;
    if (!$ext) {
        $rawExt = strtolower((string)pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
        $fallback = ['jpg'=>'jpg','jpeg'=>'jpg','png'=>'png','webp'=>'webp','gif'=>'gif','mp4'=>'mp4','webm'=>'webm'];
        $ext = $fallback[$rawExt] ?? null;
        if (!$ext) respond(['ok' => false, 'error' => 'UNSUPPORTED_FILE', 'mime' => $mime], 415);
    }
    if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) respond(['ok' => false, 'error' => 'UPLOAD_DIR'], 500);
    if (!is_writable($uploadDir)) @chmod($uploadDir, 0775);
    if (!is_writable($uploadDir)) respond(['ok' => false, 'error' => 'UPLOAD_DIR_NOT_WRITABLE'], 500);
    $base = pathinfo((string)($file['name'] ?? 'media'), PATHINFO_FILENAME);
    $base = strtolower((string)preg_replace('/[^a-zA-Z0-9_-]+/', '-', $base));
    $base = trim($base, '-') ?: 'media';
    $name = $base . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
    $target = $uploadDir . '/' . $name;
    if (!@move_uploaded_file($file['tmp_name'], $target)) {
        if (!@copy($file['tmp_name'], $target)) respond(['ok' => false, 'error' => 'UPLOAD_FAILED'], 500);
    }
    return ['path' => '/projects/uploads/' . $name, 'target' => $target, 'type' => in_array($ext, ['mp4','webm'], true) ? 'video' : 'image'];
}

$action = action();
$isConfigured = configured($configFile);

if ($action === 'status') {
    respond([
        'ok' => true,
        'configured' => $isConfigured,
        'authenticated' => !empty($_SESSION['admin']),
        'csrf' => !empty($_SESSION['admin']) ? ensureCsrf() : null,
    ]);
}

if ($action === 'setup') {
    if ($isConfigured) respond(['ok' => false, 'error' => 'ALREADY_CONFIGURED'], 409);
    $body = readJsonBody();
    $password = (string)($body['password'] ?? '');
    if (strlen($password) < 8) respond(['ok' => false, 'error' => 'PASSWORD_TOO_SHORT'], 400);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $php = "<?php\nreturn ['password_hash' => " . var_export($hash, true) . "];\n";
    if (file_put_contents($configFile, $php, LOCK_EX) === false) {
        respond(['ok' => false, 'error' => 'CONFIG_WRITE_FAILED', 'hint' => 'Проверьте права на папку api/'], 500);
    }
    $_SESSION['admin'] = true;
    session_regenerate_id(true);
    respond(['ok' => true, 'csrf' => ensureCsrf()]);
}

if ($action === 'login') {
    if (!$isConfigured) respond(['ok' => false, 'error' => 'NOT_CONFIGURED'], 409);
    $body = readJsonBody();
    $password = (string)($body['password'] ?? '');
    $cfg = config($configFile);
    if (empty($cfg['password_hash']) || !password_verify($password, (string)$cfg['password_hash'])) {
        usleep(350000);
        respond(['ok' => false, 'error' => 'WRONG_PASSWORD'], 401);
    }
    $_SESSION['admin'] = true;
    session_regenerate_id(true);
    respond(['ok' => true, 'csrf' => ensureCsrf()]);
}

if ($action === 'logout') {
    requireAuth();
    requireCsrf();
    $_SESSION = [];
    session_destroy();
    respond(['ok' => true]);
}

requireAuth();

if ($action === 'load') {
    $content = json_decode((string)@file_get_contents($contentFile), true);
    $projects = json_decode((string)@file_get_contents($projectsFile), true);
    respond([
        'ok' => true,
        'csrf' => ensureCsrf(),
        'content' => is_array($content) ? $content : [],
        'projects' => is_array($projects) ? $projects : [],
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(['ok' => false, 'error' => 'POST_REQUIRED'], 405);
requireCsrf();

if ($action === 'clear_cache') {
    clearstatcache(true);
    $opcache = false;
    if (function_exists('opcache_reset')) {
        $opcache = @opcache_reset();
    }
    if (function_exists('apcu_clear_cache')) {
        @apcu_clear_cache();
    }
    respond([
        'ok' => true,
        'cleared' => true,
        'opcache_reset' => (bool)$opcache,
        'timestamp' => time(),
    ]);
}

if ($action === 'save_content') {
    $body = readJsonBody();
    if (!isset($body['states'], $body['sections']) || !is_array($body['states']) || !is_array($body['sections'])) {
        respond(['ok' => false, 'error' => 'INVALID_CONTENT'], 400);
    }
    writeJsonAtomic($contentFile, $body);
    respond(['ok' => true]);
}

if ($action === 'save_settings') {
    $body = readJsonBody();
    $current = json_decode((string)@file_get_contents($contentFile), true);
    if (!is_array($current)) $current = [];
    if (!isset($current['settings']) || !is_array($current['settings'])) $current['settings'] = [];

    $font = static function ($value, string $fallback = 'Arial'): string {
        $value = trim((string)$value);
        if ($value === '') return $fallback;
        $value = preg_replace('/[^\p{L}\p{N} _-]+/u', '', $value);
        return substr((string)$value, 0, 80);
    };

    $settings = [
        'backgroundTheme' => max(0, min(9, (int)($body['backgroundTheme'] ?? 0))),
        'backgroundIntensity' => max(0.35, min(1.8, (float)($body['backgroundIntensity'] ?? 1))),
        'cubeOpacity' => max(0.03, min(0.65, (float)($body['cubeOpacity'] ?? 0.16))),
        'hyperSpeed' => max(0.05, min(3.0, (float)($body['hyperSpeed'] ?? 1))),
        'mainFont' => $font($body['mainFont'] ?? 'Arial'),
        'headingFont' => $font($body['headingFont'] ?? ($body['mainFont'] ?? 'Arial')),
        'uiFont' => $font($body['uiFont'] ?? ($body['mainFont'] ?? 'Arial')),
    ];

    $allowedScopes = [
        'home', 'state:1', 'state:2', 'state:3', 'state:4', 'state:5', 'state:6',
        'section:services', 'section:projects', 'section:company', 'section:lab',
        'section:shop', 'section:contacts', 'project-case'
    ];
    $incomingScopes = $body['typographyScopes'] ?? null;
    if (is_array($incomingScopes)) {
        $cleanScopes = [];
        foreach ($incomingScopes as $key => $scope) {
            if (!in_array((string)$key, $allowedScopes, true) || !is_array($scope)) continue;
            $align = (string)($scope['align'] ?? 'left');
            if (!in_array($align, ['left', 'center', 'right'], true)) $align = 'left';
            $cleanScopes[(string)$key] = [
                'headingSize' => max(16, min(120, (float)($scope['headingSize'] ?? 48))),
                'bodySize' => max(8, min(40, (float)($scope['bodySize'] ?? 14))),
                'lineHeight' => max(0.85, min(2.4, (float)($scope['lineHeight'] ?? 1.35))),
                'letterSpacing' => max(-0.08, min(0.30, (float)($scope['letterSpacing'] ?? 0))),
                'align' => $align,
            ];
        }
        $settings['typographyScopes'] = $cleanScopes;
    }

    $current['settings'] = array_merge($current['settings'], $settings);
    writeJsonAtomic($contentFile, $current);
    respond(['ok' => true, 'settings' => $current['settings']]);
}

if ($action === 'save_projects') {
    $body = readJsonBody();
    $projects = $body['projects'] ?? null;
    if (!is_array($projects)) respond(['ok' => false, 'error' => 'INVALID_PROJECTS'], 400);
    $clean = [];
    foreach ($projects as $p) {
        if (!is_array($p)) continue;
        $title = trim((string)($p['title'] ?? ''));
        if ($title === '') continue;
        $id = preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string)($p['id'] ?? ''));
        if (!$id) $id = 'project-' . bin2hex(random_bytes(5));
        $category = max(0, min(5, (int)($p['category'] ?? 0)));
        $technologies = $p['technologies'] ?? [];
        if (!is_array($technologies)) $technologies = [];
        $technologies = array_values(array_filter(array_map(static function ($v) {
            return substr(trim((string)$v), 0, 120);
        }, $technologies)));
        $projectMedia = cleanProjectMedia($p['media'] ?? [], (string)($p['image'] ?? ''), $title);
        $coverImage = projectCoverFromMedia($projectMedia, substr(trim((string)($p['image'] ?? '')), 0, 500));
        $clean[] = [
            'id' => $id,
            'title' => substr($title, 0, 160),
            'category' => $category,
            'image' => $coverImage,
            'media' => $projectMedia,
            'description' => substr(trim((string)($p['description'] ?? '')), 0, 4000),
            'year' => substr(trim((string)($p['year'] ?? '')), 0, 20),
            'published' => !empty($p['published']),
            'order' => (int)($p['order'] ?? 0),
            'client' => substr(trim((string)($p['client'] ?? '')), 0, 1000),
            'task' => substr(trim((string)($p['task'] ?? ($p['description'] ?? ''))), 0, 8000),
            'solution' => substr(trim((string)($p['solution'] ?? '')), 0, 8000),
            'implementation' => substr(trim((string)($p['implementation'] ?? '')), 0, 8000),
            'technologies' => $technologies,
            'ctaText' => substr(trim((string)($p['ctaText'] ?? '')), 0, 500),
            'ctaLink' => substr(trim((string)($p['ctaLink'] ?? '')), 0, 1000),
        ];
    }
    writeJsonAtomic($projectsFile, $clean);
    respond(['ok' => true, 'projects' => $clean]);
}



if ($action === 'update_project_media') {
    $body = readJsonBody();
    $projectId = preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string)($body['project_id'] ?? ''));
    if ($projectId === '') respond(['ok' => false, 'error' => 'PROJECT_ID_REQUIRED'], 400);
    $projects = json_decode((string)@file_get_contents($projectsFile), true);
    if (!is_array($projects)) respond(['ok' => false, 'error' => 'PROJECTS_READ_FAILED'], 500);
    $saved = null;
    foreach ($projects as &$project) {
        if (!is_array($project) || (string)($project['id'] ?? '') !== $projectId) continue;
        $media = cleanProjectMedia($body['media'] ?? [], (string)($project['image'] ?? ''), (string)($project['title'] ?? ''));
        $project['media'] = $media;
        $project['image'] = projectCoverFromMedia($media, '');
        $saved = $project;
        break;
    }
    unset($project);
    if (!is_array($saved)) respond(['ok' => false, 'error' => 'PROJECT_NOT_FOUND'], 404);
    writeJsonAtomic($projectsFile, $projects);
    respond(['ok' => true, 'project' => $saved]);
}

if ($action === 'add_project_media') {
    $projectId = preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string)($_POST['project_id'] ?? ''));
    if ($projectId === '') respond(['ok' => false, 'error' => 'PROJECT_ID_REQUIRED'], 400);
    if (empty($_FILES['file'])) respond(['ok' => false, 'error' => 'NO_FILE'], 400);
    $stored = saveUploadedMediaFile($_FILES['file'], $uploadDir);
    $projects = json_decode((string)@file_get_contents($projectsFile), true);
    if (!is_array($projects)) { @unlink($stored['target']); respond(['ok' => false, 'error' => 'PROJECTS_READ_FAILED'], 500); }
    $saved = null;
    foreach ($projects as &$project) {
        if (!is_array($project) || (string)($project['id'] ?? '') !== $projectId) continue;
        $media = cleanProjectMedia($project['media'] ?? [], (string)($project['image'] ?? ''), (string)($project['title'] ?? ''));
        $media[] = [
            'id' => 'media-' . bin2hex(random_bytes(6)),
            'src' => $stored['path'],
            'type' => $stored['type'],
            'cover' => count($media) === 0,
            'alt' => substr(trim((string)($project['title'] ?? '')), 0, 300),
        ];
        $media = cleanProjectMedia($media, '', (string)($project['title'] ?? ''));
        $project['media'] = $media;
        $project['image'] = projectCoverFromMedia($media, $stored['path']);
        $saved = $project;
        break;
    }
    unset($project);
    if (!is_array($saved)) { @unlink($stored['target']); respond(['ok' => false, 'error' => 'PROJECT_NOT_FOUND'], 404); }
    writeJsonAtomic($projectsFile, $projects);
    respond(['ok' => true, 'path' => $stored['path'], 'project' => $saved]);
}

if ($action === 'replace_project_media') {
    // One atomic endpoint: upload the file and immediately patch the exact
    // project's image field in projects.json. This avoids relying on a second
    // save_projects request after a successful upload.
    $projectId = preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string)($_POST['project_id'] ?? ''));
    if ($projectId === '') respond(['ok' => false, 'error' => 'PROJECT_ID_REQUIRED'], 400);
    if (empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
        respond(['ok' => false, 'error' => 'NO_FILE'], 400);
    }

    $file = $_FILES['file'];
    if ((int)$file['size'] > MAX_UPLOAD_BYTES) respond(['ok' => false, 'error' => 'FILE_TOO_LARGE'], 413);
    $mime = '';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = (string)$finfo->file($file['tmp_name']);
    } elseif (function_exists('mime_content_type')) {
        $mime = (string)@mime_content_type($file['tmp_name']);
    }
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        'video/mp4' => 'mp4',
        'video/webm' => 'webm',
    ];
    if (!isset($allowed[$mime])) {
        $ext = strtolower((string)pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        $fallback = ['jpg'=>'jpg','jpeg'=>'jpg','png'=>'png','webp'=>'webp','gif'=>'gif','mp4'=>'mp4','webm'=>'webm'];
        if (!isset($fallback[$ext])) respond(['ok' => false, 'error' => 'UNSUPPORTED_FILE', 'mime' => $mime], 415);
        $allowed[$mime ?: 'application/octet-stream'] = $fallback[$ext];
        $mime = $mime ?: 'application/octet-stream';
    }

    if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) respond(['ok' => false, 'error' => 'UPLOAD_DIR'], 500);
    if (!is_writable($uploadDir)) @chmod($uploadDir, 0775);
    if (!is_writable($uploadDir)) respond(['ok' => false, 'error' => 'UPLOAD_DIR_NOT_WRITABLE'], 500);

    $base = pathinfo((string)$file['name'], PATHINFO_FILENAME);
    $base = strtolower((string)preg_replace('/[^a-zA-Z0-9_-]+/', '-', $base));
    $base = trim($base, '-') ?: 'image';
    $name = $base . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $allowed[$mime];
    $targetFile = $uploadDir . '/' . $name;
    if (!@move_uploaded_file($file['tmp_name'], $targetFile)) {
        if (!@copy($file['tmp_name'], $targetFile)) respond(['ok' => false, 'error' => 'UPLOAD_FAILED'], 500);
    }
    $publicPath = '/projects/uploads/' . $name;

    $projects = json_decode((string)@file_get_contents($projectsFile), true);
    if (!is_array($projects)) {
        @unlink($targetFile);
        respond(['ok' => false, 'error' => 'PROJECTS_READ_FAILED'], 500);
    }

    $found = false;
    $savedProject = null;
    foreach ($projects as &$project) {
        if (!is_array($project)) continue;
        if ((string)($project['id'] ?? '') !== $projectId) continue;
        $project['image'] = $publicPath;
        $savedProject = $project;
        $found = true;
        break;
    }
    unset($project);
    if (!$found) {
        @unlink($targetFile);
        respond(['ok' => false, 'error' => 'PROJECT_NOT_FOUND'], 404);
    }

    writeJsonAtomic($projectsFile, $projects);

    // Read back from disk before reporting success.
    clearstatcache(true, $projectsFile);
    $check = json_decode((string)@file_get_contents($projectsFile), true);
    $verified = null;
    if (is_array($check)) {
        foreach ($check as $project) {
            if (is_array($project) && (string)($project['id'] ?? '') === $projectId) {
                $verified = $project;
                break;
            }
        }
    }
    if (!is_array($verified) || (string)($verified['image'] ?? '') !== $publicPath) {
        @unlink($targetFile);
        respond(['ok' => false, 'error' => 'MEDIA_SAVE_NOT_VERIFIED'], 500);
    }

    respond(['ok' => true, 'path' => $publicPath, 'project' => $verified]);
}

if ($action === 'upload') {
    if (empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
        respond(['ok' => false, 'error' => 'NO_FILE'], 400);
    }
    $file = $_FILES['file'];
    if ((int)$file['size'] > MAX_UPLOAD_BYTES) respond(['ok' => false, 'error' => 'FILE_TOO_LARGE'], 413);
    $mime = '';
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = (string)$finfo->file($file['tmp_name']);
    } elseif (function_exists('mime_content_type')) {
        $mime = (string)@mime_content_type($file['tmp_name']);
    }
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
        'video/mp4' => 'mp4',
        'video/webm' => 'webm',
    ];
    if (!isset($allowed[$mime])) {
        $ext = strtolower((string)pathinfo((string)$file['name'], PATHINFO_EXTENSION));
        $fallback = ['jpg'=>'jpg','jpeg'=>'jpg','png'=>'png','webp'=>'webp','gif'=>'gif','mp4'=>'mp4','webm'=>'webm'];
        if (!isset($fallback[$ext])) respond(['ok' => false, 'error' => 'UNSUPPORTED_FILE', 'mime' => $mime], 415);
        $allowed[$mime ?: 'application/octet-stream'] = $fallback[$ext];
        $mime = $mime ?: 'application/octet-stream';
    }
    if (!is_dir($uploadDir) && !@mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) respond(['ok' => false, 'error' => 'UPLOAD_DIR'], 500);
    if (!is_writable($uploadDir)) @chmod($uploadDir, 0775);
    if (!is_writable($uploadDir)) respond(['ok' => false, 'error' => 'UPLOAD_DIR_NOT_WRITABLE'], 500);
    $base = pathinfo((string)$file['name'], PATHINFO_FILENAME);
    $base = strtolower((string)preg_replace('/[^a-zA-Z0-9_-]+/', '-', $base));
    $base = trim($base, '-') ?: 'image';
    $name = $base . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $allowed[$mime];
    $target = $uploadDir . '/' . $name;
    if (!@move_uploaded_file($file['tmp_name'], $target)) {
        if (!@copy($file['tmp_name'], $target)) respond(['ok' => false, 'error' => 'UPLOAD_FAILED'], 500);
    }
    respond(['ok' => true, 'path' => '/projects/uploads/' . $name]);
}

respond(['ok' => false, 'error' => 'UNKNOWN_ACTION'], 404);
