# Dribbble import — futureddesign

Source profile: https://dribbble.com/futureddesign

Imported on 2026-08-10 from the 24 shots visible on the public profile page.
The website uses local 400px Dribbble preview images stored in `public/projects/`.

## Mapping used

- Сайты: luxemotors website, patentmarket, natashasvenson, smartline, krasglass, kamenki, jetpackaviation, belrus, flyasia, european organics, arkhigrad, transmet
- Айдентика: redroom, luxemotors identity, coolschool, tecsma branding & identity, zima, veranda
- Интерфейсы: tecsma website layouts, labelrate website
- Видео: Enduro24
- Полиграфия: almaz sweetbox, media print design x2
- Мерч: пока пусто — в публичном профиле отдельного shot для этой рубрики не найдено

This is an initial categorization based on the visible shot titles/tags. It can be manually adjusted later.
