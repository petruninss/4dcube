import * as THREE from 'three'
import './style.css'

const canvas = document.querySelector('#scene')
const reducedMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)')
let prefersReducedMotion = reducedMotionQuery.matches
reducedMotionQuery.addEventListener?.('change', (event) => { prefersReducedMotion = event.matches })

const scene = new THREE.Scene()

const camera = new THREE.PerspectiveCamera(
  45,
  window.innerWidth / window.innerHeight,
  0.1,
  100
)
camera.position.set(0, 0, 10)

const OUTER_FOV = 45
const INNER_FOV = 72
const responsiveOuterFov = () => window.innerWidth <= 720 ? 58 : OUTER_FOV
const responsiveInnerFov = () => window.innerWidth <= 720 ? 78 : INNER_FOV
const INNER_CAMERA_Z = -1.45

const renderer = new THREE.WebGLRenderer({
  canvas,
  antialias: false,
  alpha: true,
  powerPreference: 'high-performance'
});

renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, window.innerWidth <= 720 ? 1.15 : 1.6))
renderer.setSize(window.innerWidth, window.innerHeight, false)
renderer.outputColorSpace = THREE.SRGBColorSpace
renderer.setClearColor(0x000000, 0)

// Ультралёгкий процедурный фон без картинок, звёзд и сферы.
// Это полноэкранный шейдер: он рендерится только в те кадры, когда рендерится куб.
const backgroundUniforms = {
  uAspect: { value: window.innerWidth / window.innerHeight },
  uAngle: { value: 0 },
  uShift: { value: new THREE.Vector2(0, 0) },
  uTheme: { value: 0 },
  uIntensity: { value: 1.0 }
}

const backgroundMaterial = new THREE.ShaderMaterial({
  uniforms: backgroundUniforms,
  depthTest: false,
  depthWrite: false,
  transparent: false,
  vertexShader: `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position.xy, 1.0, 1.0);
    }
  `,
  fragmentShader: `
    precision mediump float;
    varying vec2 vUv;
    uniform float uAspect;
    uniform float uAngle;
    uniform vec2 uShift;
    uniform float uTheme;
    uniform float uIntensity;

    float glow(vec2 p, vec2 c, float radius) {
      float d = length(p - c);
      return 1.0 - smoothstep(0.0, radius, d);
    }

    vec3 darkSpace(vec2 w, float ribbon) {
      float a = glow(w, vec2(-0.58, 0.18), 1.05);
      float b = glow(w, vec2(0.28, -0.48), 0.92);
      float c = glow(w, vec2(0.72, 0.22), 1.02);
      float d = glow(w, vec2(-0.10, -0.75), 0.78);
      vec3 col = vec3(0.004, 0.006, 0.015);
      col += vec3(0.018, 0.075, 0.19) * a;
      col += vec3(0.010, 0.045, 0.13) * b;
      col += vec3(0.17, 0.020, 0.15) * c;
      col += vec3(0.085, 0.012, 0.11) * d;
      col += vec3(0.035, 0.020, 0.070) * ribbon;
      return col;
    }

    void main() {
      vec2 p = vUv * 2.0 - 1.0;
      p.x *= uAspect;

      float ca = cos(uAngle);
      float sa = sin(uAngle);
      p = mat2(ca, -sa, sa, ca) * p;
      p += uShift;

      vec2 w = p;
      w.x += 0.11 * sin(p.y * 2.1 + uAngle * 1.7);
      w.y += 0.08 * sin(p.x * 1.7 - uAngle * 1.2);

      float ribbon = 0.5 + 0.5 * sin((w.x * 1.15 + w.y * 0.72) * 2.8 + uAngle * 1.9);
      ribbon = smoothstep(0.40, 0.92, ribbon) * 0.10;

      vec3 col = darkSpace(w, ribbon);
      float theme = floor(uTheme + 0.5);

      if (theme == 1.0) {
        // Светлый холодный фон.
        float blue = glow(w, vec2(-0.35, 0.10), 1.35);
        float pink = glow(w, vec2(0.62, -0.25), 1.15);
        col = vec3(0.56, 0.62, 0.72);
        col += vec3(0.18, 0.24, 0.38) * blue;
        col += vec3(0.18, 0.08, 0.20) * pink;
      } else if (theme == 2.0) {
        // Почти белый.
        float blue = glow(w, vec2(-0.46, 0.18), 1.20);
        float violet = glow(w, vec2(0.45, -0.35), 1.10);
        col = vec3(0.86, 0.88, 0.92);
        col += vec3(0.07, 0.10, 0.18) * blue;
        col += vec3(0.09, 0.04, 0.12) * violet;
      } else if (theme == 3.0) {
        // Серо-синий.
        float blue = glow(w, vec2(-0.48, -0.08), 1.28);
        float steel = glow(w, vec2(0.62, 0.22), 1.20);
        col = vec3(0.055, 0.070, 0.095);
        col += vec3(0.08, 0.16, 0.28) * blue;
        col += vec3(0.06, 0.10, 0.15) * steel;
      } else if (theme == 4.0) {
        // Фиолетовый.
        float violet = glow(w, vec2(-0.42, 0.16), 1.22);
        float magenta = glow(w, vec2(0.62, -0.22), 1.05);
        col = vec3(0.018, 0.008, 0.032);
        col += vec3(0.12, 0.03, 0.24) * violet;
        col += vec3(0.18, 0.015, 0.16) * magenta;
      } else if (theme == 5.0) {
        // Без тёмных краёв: базовая палитра, но без виньетки.
        col = darkSpace(w, ribbon) * 1.08;
      } else if (theme == 6.0) {
        // Полностью без виньетки, более ровный глубокий фон.
        float blue = glow(w, vec2(-0.52, 0.05), 1.45);
        float violet = glow(w, vec2(0.52, -0.15), 1.40);
        col = vec3(0.010, 0.014, 0.025);
        col += vec3(0.025, 0.070, 0.14) * blue;
        col += vec3(0.07, 0.025, 0.11) * violet;
      } else if (theme == 7.0) {
        // Более яркий центр.
        float center = glow(w, vec2(0.02, 0.02), 1.12);
        col = darkSpace(w, ribbon);
        col += vec3(0.08, 0.12, 0.22) * center;
      } else if (theme == 8.0) {
        // Мягкие цветные пятна.
        float c1 = glow(w, vec2(-0.70, 0.22), 0.88);
        float c2 = glow(w, vec2(0.52, 0.30), 0.82);
        float c3 = glow(w, vec2(0.12, -0.60), 0.92);
        col = vec3(0.006, 0.008, 0.018);
        col += vec3(0.020, 0.12, 0.22) * c1;
        col += vec3(0.20, 0.025, 0.17) * c2;
        col += vec3(0.08, 0.035, 0.18) * c3;
      } else if (theme == 9.0) {
        // Альтернативная композиция под другое направление движения.
        float c1 = glow(w, vec2(-0.15, 0.62), 1.18);
        float c2 = glow(w, vec2(0.68, -0.42), 1.04);
        col = vec3(0.004, 0.006, 0.014);
        col += vec3(0.025, 0.10, 0.20) * c1;
        col += vec3(0.16, 0.020, 0.13) * c2;
      }

      // Виньетка есть только у тем, где она нужна.
      if (theme != 5.0 && theme != 6.0 && theme != 1.0 && theme != 2.0) {
        vec2 q = vUv - 0.5;
        float vignette = smoothstep(0.92, 0.22, length(q));
        col *= mix(0.54, 1.0, vignette);
      }

      col *= uIntensity;
      gl_FragColor = vec4(col, 1.0);
    }
  `
})
const background = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), backgroundMaterial)
background.renderOrder = -100
background.frustumCulled = false
scene.add(background)

const heroTitle = document.querySelector('.hero h1')
const heroText = document.querySelector('.hero p')
const statusText = document.querySelector('.status')

const cubeGroup = new THREE.Group()
scene.add(cubeGroup)

const faces = [
  { number: 3, title: 'КОМПАНИЯ', color: 0x4b3b62 },
  { number: 1, title: 'УСЛУГИ', color: 0x203652 },
  { number: 5, title: 'МАГАЗИН', color: 0x2d544a },
  { number: 6, title: 'КОНТАКТЫ', color: 0x5a3d2d },
  { number: 2, title: 'ПРОЕКТЫ', color: 0x553060 },
  { number: 4, title: 'ЛАБОРАТОРИЯ', color: 0x38384e }
]

const FACE_SCALE = 1.40
const FACE_OPACITY = 0.20
const CUBE_SIZE = 3.5
const HALF = CUBE_SIZE / 2
const LABEL_OFFSET = 0.015
const NORMAL_SCALE = 1

// Ультралёгкий свет: без HemisphereLight, transmission, clearcoat и tone mapping.
const ambientLight = new THREE.AmbientLight(0xffffff, 0.72)
scene.add(ambientLight)

const keyLight = new THREE.DirectionalLight(0xffffff, 1.55)
keyLight.position.set(6, 8, 7)
scene.add(keyLight)

const fillLight = new THREE.DirectionalLight(0x9bb7ff, 0.32)
fillLight.position.set(-5, 2, 3)
scene.add(fillLight)

const faceGeometry = new THREE.PlaneGeometry(CUBE_SIZE, CUBE_SIZE)
const faceMeshes = []

function createFaceMaterial(face) {
  return new THREE.MeshPhongMaterial({
    color: face.color,
    transparent: true,
    opacity: FACE_OPACITY,
    shininess: 72,
    specular: 0x8ca6c9,
    side: THREE.DoubleSide,
    depthWrite: false,
    depthTest: true
  })
}

const faceTransforms = [
  { position: [ HALF, 0, 0], rotation: [0,  Math.PI / 2, 0] },
  { position: [-HALF, 0, 0], rotation: [0, -Math.PI / 2, 0] },
  { position: [0,  HALF, 0], rotation: [-Math.PI / 2, 0, 0] },
  { position: [0, -HALF, 0], rotation: [ Math.PI / 2, 0, 0] },
  { position: [0, 0,  HALF], rotation: [0, 0, 0] },
  { position: [0, 0, -HALF], rotation: [0, Math.PI, 0] }
]

faces.forEach((face, index) => {
  const mesh = new THREE.Mesh(faceGeometry, createFaceMaterial(face))
  const t = faceTransforms[index]
  mesh.position.set(...t.position)
  mesh.rotation.set(...t.rotation)
  faceMeshes.push(mesh)
  cubeGroup.add(mesh)
})


const FACE_TILE_GRID = 5
const FACE_TILE_GAP = 0.92
const FACE_TILE_BASE_OPACITY = 0.24
const FACE_TILE_MAX_OPACITY = 0.58
const FACE_TILE_MAX_TILT = 0.22
const interactiveFaceTiles = []
const flashlightState = {
  hoveredFaceIndex: -1,
  active: false,
  localPoint: new THREE.Vector3(),
  easedPoint: new THREE.Vector3(),
  lastMoveAt: 0
}
const tileWhite = new THREE.Color(0xffffff)

function createFaceTileMaterial(face) {
  return new THREE.MeshPhongMaterial({
    color: face.color,
    transparent: true,
    opacity: 0,
    shininess: 94,
    specular: 0xffffff,
    side: THREE.DoubleSide,
    depthWrite: false,
    depthTest: true
  })
}

faces.forEach((face, index) => {
  const t = faceTransforms[index]
  const group = new THREE.Group()
  group.position.set(...t.position)
  group.rotation.set(...t.rotation)
  group.visible = true

  const step = CUBE_SIZE / FACE_TILE_GRID
  const tileGeometry = new THREE.PlaneGeometry(step * FACE_TILE_GAP, step * FACE_TILE_GAP)
  const tiles = []

  for (let row = 0; row < FACE_TILE_GRID; row += 1) {
    for (let col = 0; col < FACE_TILE_GRID; col += 1) {
      const tile = new THREE.Mesh(tileGeometry, createFaceTileMaterial(face))
      const x = -CUBE_SIZE * 0.5 + step * (col + 0.5)
      const y = CUBE_SIZE * 0.5 - step * (row + 0.5)
      tile.position.set(x, y, 0.024)
      tile.userData = {
        basePosition: tile.position.clone(),
        currentRotX: 0,
        currentRotY: 0,
        currentLift: 0,
        currentOpacity: 0,
        currentBrightness: 0
      }
      tiles.push(tile)
      group.add(tile)
    }
  }

  interactiveFaceTiles.push({
    group,
    tiles,
    color: new THREE.Color(face.color),
    step
  })

  cubeGroup.add(group)
})

// === V10 EXPERIMENTAL HYPERCUBE INTRO ===
// A true 4D tesseract is rotated in XW/YW/ZW planes and projected into 3D.
// We render only translucent square membranes — no edge/wireframe outlines.
const hypercubeGroup = new THREE.Group()
scene.add(hypercubeGroup)
const applyResponsiveSceneScale = () => {
  const mobile = window.innerWidth <= 720
  hypercubeGroup.scale.setScalar(mobile ? 0.78 : 1)
  if (!isAnimating) {
    camera.fov = insideSection ? responsiveInnerFov() : responsiveOuterFov()
    camera.updateProjectionMatrix()
  }
}

const HYPER_COORD = 1.0
const HYPER_WORLD_SCALE = 1.456
const HYPER_W_CAMERA = 3.15
const HYPER_HOME_QUATERNION = new THREE.Quaternion().setFromEuler(
  new THREE.Euler(
    THREE.MathUtils.degToRad(-10),
    THREE.MathUtils.degToRad(28),
    0,
    'XYZ'
  )
)
const hyper4Vertices = []
for (let i = 0; i < 16; i += 1) {
  hyper4Vertices.push([
    (i & 1) ? HYPER_COORD : -HYPER_COORD,
    (i & 2) ? HYPER_COORD : -HYPER_COORD,
    (i & 4) ? HYPER_COORD : -HYPER_COORD,
    (i & 8) ? HYPER_COORD : -HYPER_COORD
  ])
}

function hyperVertexIndex(coords) {
  let index = 0
  if (coords[0] > 0) index |= 1
  if (coords[1] > 0) index |= 2
  if (coords[2] > 0) index |= 4
  if (coords[3] > 0) index |= 8
  return index
}

const hyperSquareFaces = []
for (let axisA = 0; axisA < 4; axisA += 1) {
  for (let axisB = axisA + 1; axisB < 4; axisB += 1) {
    const fixedAxes = [0, 1, 2, 3].filter((axis) => axis !== axisA && axis !== axisB)
    for (const fixedA of [-1, 1]) {
      for (const fixedB of [-1, 1]) {
        const indices = []
        for (const [a, b] of [[-1,-1], [1,-1], [1,1], [-1,1]]) {
          const c = [0, 0, 0, 0]
          c[axisA] = a
          c[axisB] = b
          c[fixedAxes[0]] = fixedA
          c[fixedAxes[1]] = fixedB
          indices.push(hyperVertexIndex(c))
        }
        hyperSquareFaces.push(indices)
      }
    }
  }
}

const hyperFaceMeshes = hyperSquareFaces.map((indices, index) => {
  const geometry = new THREE.BufferGeometry()
  const positions = new Float32Array(12)
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
  geometry.setIndex([0, 1, 2, 0, 2, 3])
  const sourceFace = faces[index % faces.length]
  const material = new THREE.MeshPhongMaterial({
    color: sourceFace.color,
    transparent: true,
    opacity: 0.09 + (index % 4) * 0.012,
    shininess: 92,
    specular: 0xa8b9df,
    side: THREE.DoubleSide,
    depthWrite: false,
    depthTest: true,
    blending: THREE.NormalBlending
  })
  material.userData.baseOpacity = material.opacity
  const mesh = new THREE.Mesh(geometry, material)
  mesh.userData.hyperIndices = indices
  mesh.frustumCulled = false
  hypercubeGroup.add(mesh)
  return mesh
})

let hyperAngleXW = 0.18
let hyperAngleYW = -0.34
let hyperAngleZW = 0.12
let hyperAngleXY = 0.20
let hyperSpeedMultiplier = 1
let hyperBlend = 1
let hyperTarget = 1
let hyperLoopFrame = null
let hyperLastTime = performance.now()
let hyperPointerOver = false
let hyperReturnTimer = null

function rotate4DPoint(source, axw, ayw, azw, axy) {
  let [x, y, z, w] = source
  let c = Math.cos(axw), si = Math.sin(axw)
  ;[x, w] = [x * c - w * si, x * si + w * c]
  c = Math.cos(ayw); si = Math.sin(ayw)
  ;[y, w] = [y * c - w * si, y * si + w * c]
  c = Math.cos(azw); si = Math.sin(azw)
  ;[z, w] = [z * c - w * si, z * si + w * c]
  c = Math.cos(axy); si = Math.sin(axy)
  ;[x, y] = [x * c - y * si, x * si + y * c]
  return [x, y, z, w]
}

function projectHyperPoint(point) {
  const [x, y, z, w] = point
  const perspective = HYPER_W_CAMERA / Math.max(1.35, HYPER_W_CAMERA - w)
  return new THREE.Vector3(
    x * perspective * HYPER_WORLD_SCALE,
    y * perspective * HYPER_WORLD_SCALE,
    z * perspective * HYPER_WORLD_SCALE
  )
}

function updateHypercubeGeometry() {
  const homeQuat = HYPER_HOME_QUATERNION
  const morph = THREE.MathUtils.clamp(hyperBlend, 0, 1)
  const projected = hyper4Vertices.map((vertex) => {
    const hyperPoint = projectHyperPoint(
      rotate4DPoint(vertex, hyperAngleXW, hyperAngleYW, hyperAngleZW, hyperAngleXY)
    )
    // Collapse the W dimension onto the eight vertices of the ordinary cube.
    // Both W layers converge to the same XYZ corner, so the tesseract itself
    // visibly becomes the current static cube instead of being swapped out.
    const cubePoint = new THREE.Vector3(
      vertex[0] * HALF,
      vertex[1] * HALF,
      vertex[2] * HALF
    ).applyQuaternion(homeQuat)
    return cubePoint.lerp(hyperPoint, morph)
  })
  hyperFaceMeshes.forEach((mesh) => {
    const positions = mesh.geometry.attributes.position.array
    mesh.userData.hyperIndices.forEach((vertexIndex, cornerIndex) => {
      const point = projected[vertexIndex]
      positions[cornerIndex * 3] = point.x
      positions[cornerIndex * 3 + 1] = point.y
      positions[cornerIndex * 3 + 2] = point.z
    })
    mesh.geometry.attributes.position.needsUpdate = true
    mesh.geometry.computeVertexNormals()
  })
}

function applyHyperBlend() {
  const homeOutside = !insideSection && activeState === 0
  const b = homeOutside ? THREE.MathUtils.clamp(hyperBlend, 0, 1) : 0

  // Keep the hypercube fully visible while it geometrically collapses.
  // Only at the very end do we hand off to the ordinary cube and its labels.
  const handoff = 0.055
  const hyperVisual = b >= handoff ? 1 : THREE.MathUtils.clamp(b / handoff, 0, 1)
  const cubeVisual = b >= handoff ? 0 : 1 - hyperVisual
  const solidify = 1 + (1 - b) * 0.55

  hypercubeGroup.visible = homeOutside && (b > 0.001 || hyperVisual > 0.001)
  hyperFaceMeshes.forEach((mesh) => {
    mesh.material.opacity = mesh.material.userData.baseOpacity * hyperVisual * solidify
  })
  faceMeshes.forEach((mesh) => { mesh.material.opacity = FACE_OPACITY * cubeVisual })
  outerFaceLabels.forEach((label) => {
    if (label.visible) label.material.opacity = cubeVisual
  })
  faceSignatures.forEach((signature) => {
    if (signature.visible) setFaceSignatureOpacity(signature, (signature.userData.displayOpacity ?? 0) * cubeVisual)
  })
}

function hypercubeTick(now) {
  hyperLoopFrame = null
  if (insideSection || activeState !== 0 || isAnimating) {
    hyperBlend = 0
    applyHyperBlend()
    renderScene()
    return
  }
  const dt = Math.min(0.04, Math.max(0.001, (now - hyperLastTime) / 1000))
  hyperLastTime = now
  const blendEase = prefersReducedMotion ? 1 : 1 - Math.exp(-dt * (hyperTarget < hyperBlend ? 8.55 : 3.7))
  hyperBlend = THREE.MathUtils.lerp(hyperBlend, hyperTarget, blendEase)
  const motion = prefersReducedMotion ? 0 : Math.max(0.0, hyperBlend)
  if (motion > 0.002) {
    hyperAngleXW += dt * 0.36 * motion * hyperSpeedMultiplier
    hyperAngleYW += dt * 0.27 * motion * hyperSpeedMultiplier
    hyperAngleZW += dt * 0.18 * motion * hyperSpeedMultiplier
    hyperAngleXY += dt * 0.065 * motion * hyperSpeedMultiplier
  }
  updateHypercubeGeometry()
  applyHyperBlend()
  renderScene()
  if (hyperTarget > 0.001 || hyperBlend > 0.003) {
    hyperLoopFrame = requestAnimationFrame(hypercubeTick)
  }
}

function ensureHypercubeLoop() {
  if (hyperLoopFrame != null) return
  hyperLastTime = performance.now()
  hyperLoopFrame = requestAnimationFrame(hypercubeTick)
}

function setHyperStable(stable, immediate = false) {
  clearTimeout(hyperReturnTimer)
  hyperReturnTimer = null
  hyperTarget = stable ? 0 : 1
  if (immediate) hyperBlend = hyperTarget
  applyHyperBlend()
  ensureHypercubeLoop()
}

function scheduleHyperReturn() {
  clearTimeout(hyperReturnTimer)
  hyperReturnTimer = setTimeout(() => {
    if (!hyperPointerOver && !insideSection && activeState === 0 && !isAnimating) setHyperStable(false)
  }, 850)
}

function hyperFaceIndexFromPointer(event) {
  if (insideSection || activeState !== 0 || hyperBlend < 0.02) return -1
  const rect = canvas.getBoundingClientRect()
  cubePointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  cubePointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
  cubeRaycaster.setFromCamera(cubePointer, camera)
  const hits = cubeRaycaster.intersectObjects(hyperFaceMeshes, false)
  return hits.length ? hyperFaceMeshes.indexOf(hits[0].object) : -1
}

updateHypercubeGeometry()

let cubeLabelFontFamily = 'Arial'


function makeLabelTexture(number, title, glow = false) {
  const size = 384
  const c = document.createElement('canvas')
  c.width = size
  c.height = size
  const ctx = c.getContext('2d')
  ctx.clearRect(0, 0, size, size)

  ctx.fillStyle = 'rgba(255,255,255,0.74)'
  ctx.font = `600 24px ${cubeLabelFontFamily}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'top'
  ctx.fillText(String(number).padStart(2, '0'), 31, 28)

  ctx.fillStyle = '#ffffff'
  if (glow) {
    ctx.shadowColor = 'rgba(255,255,255,0.98)'
    ctx.shadowBlur = 18
  } else {
    ctx.shadowColor = 'transparent'
    ctx.shadowBlur = 0
  }
  ctx.font = `700 40px ${cubeLabelFontFamily}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'

  const words = title.toUpperCase().split(' ')
  if (words.length === 1) {
    ctx.fillText(words[0], size / 2, size / 2)
  } else {
    ctx.fillText(words[0], size / 2, size / 2 - 29)
    ctx.fillText(words.slice(1).join(' '), size / 2, size / 2 + 29)
  }

  ctx.shadowBlur = 0
  ctx.shadowColor = 'transparent'

  const texture = new THREE.CanvasTexture(c)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.generateMipmaps = false
  texture.minFilter = THREE.LinearFilter
  texture.magFilter = THREE.LinearFilter
  return texture
}

const labelGeometry = new THREE.PlaneGeometry(3.15, 3.15)
const outerFaceLabels = []
let hoveredOuterLabelIndex = -1

faces.forEach((face, index) => {
  const material = new THREE.MeshBasicMaterial({
    map: makeLabelTexture(face.number, face.title),
    transparent: true,
    opacity: 1,
    side: THREE.FrontSide,
    depthTest: true,
    depthWrite: false
  })

  const label = new THREE.Mesh(labelGeometry, material)
  const t = faceTransforms[index]
  const outward = {
    0: [ LABEL_OFFSET, 0, 0],
    1: [-LABEL_OFFSET, 0, 0],
    2: [0, LABEL_OFFSET, 0],
    3: [0, -LABEL_OFFSET, 0],
    4: [0, 0, LABEL_OFFSET],
    5: [0, 0, -LABEL_OFFSET]
  }[index]

  label.position.set(
    t.position[0] + outward[0],
    t.position[1] + outward[1],
    t.position[2] + outward[2]
  )
  label.rotation.set(...t.rotation)
  label.renderOrder = 2
  outerFaceLabels.push(label)
  cubeGroup.add(label)
})

// === V10.9.9 RADIANT EFFECTS / TRANSPARENT + FASTER 4DKUB PALETTE ===
// The original MIT-licensed Radiant examples remain unchanged as source material.
// We preload all six local HTML documents during the branded intro, capture a ready
// frame for each one, then reuse the cached source on section switches. The live
// source canvas is color-treated into the 4DKUB face palette before it reaches Three.js.
const FACE_SIGNATURE_PLANE = new THREE.PlaneGeometry(CUBE_SIZE - 0.04, CUBE_SIZE - 0.04)
const faceSignatures = []
let faceSignatureFrame = null
let faceSignatureLast = 0
let faceSignaturePulseUntil = 0

const RADIANT_EFFECT_FILES = [
  'clockwork-mind.html',     // company
  'flow-field.html',         // services
  'spark-chamber.html',      // shop
  'resonant-strings.html',   // contacts
  'gothic-filigree.html',    // projects
  'digital-rain.html'        // lab
]

const RADIANT_FACE_COLORS = [
  '#ffffff', // company
  '#ffffff', // services
  '#ffffff', // shop
  '#ffffff', // contacts
  '#ffffff', // projects
  '#ffffff'  // lab
]
const RADIANT_TEXTURE_ALPHA = 0.66
const RADIANT_SPEED_MULTIPLIER = 2.2
const RADIANT_RUNTIME_FACES = [0, 1, 2, 3, 4, 5]
const radiantSources = new Map()
const radiantSnapshots = new Map()

const radiantHost = document.createElement('div')
radiantHost.className = 'radiant-effect-host'
radiantHost.setAttribute('aria-hidden', 'true')
document.body.appendChild(radiantHost)

let radiantActiveFace = -1
let radiantCanvas = null
let radiantOutputCanvas = null
let radiantOutputCtx = null
let radiantTexture = null
let radiantLoadToken = 0

function injectRadiantBase(source, faceIndex = -1) {
  if (!source) return ''
  const base = `<base href="${location.origin}/radiant/">`
  const style = `<style>html,body{background:transparent!important;}canvas{background:transparent!important;}</style>`
  const speed = faceIndex === 4 ? 0.68 : faceIndex === 3 ? 0.62 : faceIndex === 2 ? 1.6 : faceIndex === 0 ? 0.86 : RADIANT_SPEED_MULTIPLIER
  const runtime = `<script>(function(){const SPEED=${speed.toFixed(2)};const nativePerfNow=performance.now.bind(performance);const perfStart=nativePerfNow();const scaledNow=()=>perfStart+((nativePerfNow()-perfStart)*SPEED);try{Object.defineProperty(performance,'now',{configurable:true,value:scaledNow});}catch(_){try{performance.now=scaledNow;}catch(__){}}const nativeDateNow=Date.now.bind(Date);const dateStart=nativeDateNow();try{Date.now=()=>Math.round(dateStart+((nativeDateNow()-dateStart)*SPEED));}catch(_){ }const nativeRAF=window.requestAnimationFrame.bind(window);window.requestAnimationFrame=(callback)=>nativeRAF((time)=>callback(perfStart+((time-perfStart)*SPEED)));window.__RADIANT_SPEED__=SPEED;})();<\/script>`
  const injected = `${base}${style}${runtime}`
  return source.includes('<head>') ? source.replace('<head>', `<head>${injected}`) : `${injected}${source}`
}

function colorizeRadiantCanvas(sourceCanvas, targetCanvas, faceIndex, now = performance.now()) {
  if (!sourceCanvas || !targetCanvas) return
  const width = Math.max(1, sourceCanvas.width || 640)
  const height = Math.max(1, sourceCanvas.height || 640)
  if (targetCanvas.width !== width) targetCanvas.width = width
  if (targetCanvas.height !== height) targetCanvas.height = height
  const ctx = targetCanvas.getContext('2d', { alpha: true, willReadFrequently: true })
  if (!ctx) return

  const tint = new THREE.Color(RADIANT_FACE_COLORS[faceIndex] || '#ffffff')
  const baseR = Math.round(tint.r * 255)
  const baseG = Math.round(tint.g * 255)
  const baseB = Math.round(tint.b * 255)

  ctx.clearRect(0, 0, width, height)
  ctx.save()
  ctx.filter = 'grayscale(1) contrast(1.82) brightness(1.42)'
  if (faceIndex === 1) {
    const scale = 1.56
    const dw = width * scale
    const dh = height * scale
    const dx = (width - dw) * 0.5
    const dy = (height - dh) * 0.5
    const trail = [
      { ox: 0, oy: 0, a: 0.55 },
      { ox: -14, oy: -8, a: 0.22 },
      { ox: -28, oy: -16, a: 0.14 },
      { ox: -42, oy: -24, a: 0.08 }
    ]
    trail.forEach(({ ox, oy, a }) => {
      ctx.globalAlpha = a
      ctx.drawImage(sourceCanvas, dx + ox, dy + oy, dw, dh)
    })
    ctx.globalAlpha = 1
  } else if (faceIndex === 3) {
    const scale = 2.35
    const dw = width * scale
    const dh = height * scale
    const dx = (width - dw) * 0.5
    const dy = (height - dh) * 0.5
    ctx.globalAlpha = 0.96
    ctx.drawImage(sourceCanvas, dx, dy, dw, dh)
    ctx.globalAlpha = 1
  } else if (faceIndex === 4) {
    const cycle = (1 - Math.cos(now * 0.00024)) * 0.5
    const eased = Math.pow(cycle, 1.24)
    const scale = 0.035 + eased * 1.34
    const alphaWave = 0.06 + eased * 0.52
    const dw = width * scale
    const dh = height * scale
    const dx = (width - dw) * 0.5
    const dy = (height - dh) * 0.5
    ctx.globalAlpha = alphaWave
    ctx.drawImage(sourceCanvas, dx, dy, dw, dh)
    ctx.globalAlpha = 1
  } else {
    ctx.drawImage(sourceCanvas, 0, 0, width, height)
  }
  ctx.filter = 'none'
  ctx.restore()

  const frame = ctx.getImageData(0, 0, width, height)
  const data = frame.data

  for (let i = 0; i < data.length; i += 4) {
    const sr = data[i]
    const sg = data[i + 1]
    const sb = data[i + 2]
    const rawAlpha = data[i + 3] / 255
    const luminance = (0.2126 * sr + 0.7152 * sg + 0.0722 * sb) / 255
    const energy = Math.max(luminance, sr / 255, sg / 255, sb / 255)
    let signal = (energy - 0.05) / 0.95
    if (signal <= 0 || rawAlpha <= 0) {
      data[i] = 0
      data[i + 1] = 0
      data[i + 2] = 0
      data[i + 3] = 0
      continue
    }

    signal = Math.min(1, signal)
    signal = Math.pow(signal, 0.52)
    let alpha
    if (faceIndex === 2) {
      const sparkle = Math.max(0, (signal - 0.66) / 0.34)
      alpha = Math.min(1, (Math.pow(signal, 2.15) * 2.0 + sparkle * 0.28) * rawAlpha)
    } else if (faceIndex === 4) {
      alpha = Math.min(1, signal * 0.92) * rawAlpha
    } else {
      alpha = Math.min(1, signal * 1.45) * rawAlpha
    }

    data[i] = 255
    data[i + 1] = 255
    data[i + 2] = 255
    data[i + 3] = Math.round(255 * alpha)
  }

  ctx.clearRect(0, 0, width, height)
  ctx.putImageData(frame, 0, 0)
}


const CUSTOM_FACE_EFFECTS = new Set()
let radiantCustomEffect = null

function faceColorRgb(faceIndex) {
  const c = new THREE.Color(RADIANT_FACE_COLORS[faceIndex] || '#ffffff')
  return [Math.round(c.r * 255), Math.round(c.g * 255), Math.round(c.b * 255)]
}

function createCustomFaceEffect(faceIndex) {
  const canvas = document.createElement('canvas')
  canvas.width = 640
  canvas.height = 640
  const ctx = canvas.getContext('2d', { alpha: true })
  const [r, g, b] = faceColorRgb(faceIndex)
  const line = (a = 0.5) => `rgba(${r},${g},${b},${a})`
  const bright = (a = 0.7) => `rgba(255,255,255,${a})`

  const drawCompany = (now) => {
    const t = now * 0.00135
    ctx.clearRect(0, 0, 640, 640)
    ctx.save()
    ctx.translate(320, 320)
    const layers = 5
    for (let layer = 0; layer < layers; layer += 1) {
      const count = 6 + layer * 2
      const radius = 76 + layer * 52 + Math.sin(t * 1.15 + layer) * 5
      ctx.beginPath()
      for (let i = 0; i < count; i += 1) {
        const a = (i / count) * Math.PI * 2 + t * (0.13 + layer * 0.016) * (layer % 2 ? -1 : 1)
        const x = Math.cos(a) * radius
        const y = Math.sin(a) * radius * 0.72
        if (i === 0) ctx.moveTo(x, y)
        else ctx.lineTo(x, y)
      }
      ctx.closePath()
      ctx.strokeStyle = line(0.16 + layer * 0.04)
      ctx.lineWidth = 1.05
      ctx.stroke()
    }
    const nodes = []
    for (let i = 0; i < 24; i += 1) {
      const ring = 1 + (i % 4)
      const a = i * 2.399 + t * (0.18 + ring * 0.028)
      const rad = 88 + ring * 44
      nodes.push([Math.cos(a) * rad, Math.sin(a) * rad * 0.72])
    }
    ctx.lineWidth = 0.76
    nodes.forEach((p, i) => {
      const q = nodes[(i * 7 + 5) % nodes.length]
      ctx.beginPath()
      ctx.moveTo(p[0], p[1])
      ctx.lineTo(q[0], q[1])
      ctx.strokeStyle = line(0.11)
      ctx.stroke()
    })
    nodes.forEach((p, i) => {
      const pulse = 0.52 + 0.48 * Math.sin(t * 2.8 + i * 0.75)
      ctx.beginPath()
      ctx.arc(p[0], p[1], 2.0 + pulse * 1.8, 0, Math.PI * 2)
      ctx.fillStyle = i % 4 === 0 ? bright(0.68) : line(0.34 + pulse * 0.16)
      ctx.fill()
    })
    // brighter micro-points to enliven the structure
    for (let i = 0; i < 42; i += 1) {
      const a = i * 0.72 + t * (0.22 + (i % 5) * 0.02)
      const rad = 52 + (i % 7) * 34 + Math.sin(t * 0.8 + i) * 8
      const x = Math.cos(a) * rad
      const y = Math.sin(a * 1.08) * rad * 0.58
      const pulse = 0.35 + 0.65 * ((Math.sin(t * 3.2 + i * 0.9) + 1) * 0.5)
      ctx.beginPath()
      ctx.arc(x, y, 0.9 + pulse * 1.6, 0, Math.PI * 2)
      ctx.fillStyle = bright(0.18 + pulse * 0.48)
      ctx.fill()
    }
    ctx.restore()
  }

  const drawShop = (now) => {
    const t = now * 0.00044
    ctx.clearRect(0, 0, 640, 640)

    const belts = [168, 258, 350, 442]
    belts.forEach((y, row) => {
      // rails
      ctx.strokeStyle = line(0.14)
      ctx.lineWidth = 1
      ctx.beginPath()
      ctx.moveTo(72, y)
      ctx.lineTo(568, y)
      ctx.moveTo(72, y + 26)
      ctx.lineTo(568, y + 26)
      ctx.stroke()

      // cross ticks
      for (let x = 92; x <= 552; x += 44) {
        const shift = ((t * 110) + row * 11) % 44
        const px = x - shift
        ctx.beginPath()
        ctx.moveTo(px, y)
        ctx.lineTo(px, y + 26)
        ctx.strokeStyle = line(0.08)
        ctx.stroke()
      }

      // modules drifting like delicate conveyor items
      for (let i = 0; i < 4; i += 1) {
        const cycle = 150
        const travel = ((t * (92 + row * 10) + i * 0.24) % 1)
        const x = 88 + travel * 460
        const bob = Math.sin(t * 4.2 + row + i * 1.3) * 2.4
        const w = 28 + (i % 2) * 10
        const h = 16 + ((i + row) % 2) * 5
        ctx.save()
        ctx.translate(x, y + 13 + bob)
        ctx.strokeStyle = line(0.24)
        ctx.lineWidth = 1.05
        ctx.strokeRect(-w * 0.5, -h * 0.5, w, h)
        ctx.beginPath()
        ctx.moveTo(-w * 0.22, -h * 0.5)
        ctx.lineTo(-w * 0.22, h * 0.5)
        ctx.moveTo(w * 0.16, -h * 0.5)
        ctx.lineTo(w * 0.16, h * 0.5)
        ctx.strokeStyle = line(0.12)
        ctx.stroke()
        if (i % 2 === 0) {
          ctx.beginPath()
          ctx.arc(0, 0, 2.1, 0, Math.PI * 2)
          ctx.fillStyle = bright(0.42)
          ctx.fill()
        }
        ctx.restore()
      }
    })

    // subtle vertical sorting guides
    ;[138, 250, 390, 512].forEach((x, idx) => {
      const glow = 0.08 + ((Math.sin(t * 2.4 + idx) + 1) * 0.5) * 0.1
      ctx.strokeStyle = line(glow)
      ctx.beginPath()
      ctx.moveTo(x, 126)
      ctx.lineTo(x, 486)
      ctx.stroke()
    })
  }

  const drawContacts = (now) => {
    const t = now * 0.00056
    ctx.clearRect(0, 0, 640, 640)

    const nodes = [
      [104,150],[214,108],[346,128],[470,98],[540,172],
      [132,282],[250,232],[382,254],[518,300],
      [104,424],[226,388],[360,416],[482,398],[540,500]
    ]
    const links = [
      [0,1],[1,2],[2,3],[3,4],
      [0,5],[1,6],[2,7],[4,8],
      [5,6],[6,7],[7,8],
      [5,9],[6,10],[7,11],[8,12],[12,13],
      [9,10],[10,11],[11,12],
      [1,5],[2,6],[3,7],[7,12]
    ]

    const pts = nodes.map((p, i) => {
      const a = t * (0.5 + (i % 3) * 0.08) + i * 0.7
      return [p[0] + Math.cos(a) * 3.5, p[1] + Math.sin(a * 0.95) * 3.5]
    })

    // map grid suggestion
    for (let gx = 94; gx <= 546; gx += 112) {
      ctx.strokeStyle = line(0.045)
      ctx.beginPath()
      ctx.moveTo(gx, 92)
      ctx.lineTo(gx, 548)
      ctx.stroke()
    }
    for (let gy = 118; gy <= 518; gy += 96) {
      ctx.beginPath()
      ctx.moveTo(86, gy)
      ctx.lineTo(556, gy)
      ctx.strokeStyle = line(0.045)
      ctx.stroke()
    }

    // curved communication links
    links.forEach(([ai, bi], idx) => {
      const a = pts[ai], b = pts[bi]
      const cx = (a[0] + b[0]) * 0.5 + (idx % 2 ? 14 : -14)
      const cy = (a[1] + b[1]) * 0.5 - 12
      ctx.beginPath()
      ctx.moveTo(a[0], a[1])
      ctx.quadraticCurveTo(cx, cy, b[0], b[1])
      ctx.strokeStyle = line(0.11)
      ctx.lineWidth = 1
      ctx.stroke()
    })

    // node pings / geolocation marks
    pts.forEach((p, i) => {
      const pulse = ((Math.sin(t * 4.4 + i * 0.7) + 1) * 0.5)
      ctx.beginPath()
      ctx.arc(p[0], p[1], 2 + pulse * 1.4, 0, Math.PI * 2)
      ctx.fillStyle = bright(0.34 + pulse * 0.28)
      ctx.fill()
      if (i % 3 === 0) {
        ctx.beginPath()
        ctx.arc(p[0], p[1], 8 + pulse * 7, 0, Math.PI * 2)
        ctx.strokeStyle = line(0.06 + pulse * 0.08)
        ctx.stroke()
      }
    })

    // travelling communication impulses
    for (let k = 0; k < 5; k += 1) {
      const edge = links[(Math.floor(t * 18) + k * 4) % links.length]
      const a = pts[edge[0]], b = pts[edge[1]]
      const phase = (t * (0.22 + k * 0.015) + k * 0.12) % 1
      const cx = (a[0] + b[0]) * 0.5 + (((edge[0] + edge[1]) % 2) ? 14 : -14)
      const cy = (a[1] + b[1]) * 0.5 - 12
      const inv = 1 - phase
      const x = inv * inv * a[0] + 2 * inv * phase * cx + phase * phase * b[0]
      const y = inv * inv * a[1] + 2 * inv * phase * cy + phase * phase * b[1]
      ctx.beginPath()
      ctx.arc(x, y, 2.6, 0, Math.PI * 2)
      ctx.fillStyle = bright(0.62)
      ctx.fill()
    }
  }

  const update = faceIndex === 0 ? drawCompany : faceIndex === 2 ? drawShop : drawContacts
  update(performance.now())
  return { canvas, update }
}

function attachCustomFaceEffect(faceIndex) {
  const mesh = faceSignatures[faceIndex]
  if (!mesh) return false
  radiantCustomEffect = createCustomFaceEffect(faceIndex)
  radiantCanvas = radiantCustomEffect.canvas
  radiantOutputCanvas = radiantCustomEffect.canvas
  radiantOutputCtx = radiantCustomEffect.canvas.getContext('2d')
  const texture = new THREE.CanvasTexture(radiantCustomEffect.canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.minFilter = THREE.LinearFilter
  texture.magFilter = THREE.LinearFilter
  texture.generateMipmaps = false
  if (radiantTexture) radiantTexture.dispose()
  radiantTexture = texture
  mesh.material.map = texture
  mesh.material.needsUpdate = true
  return true
}

function clearRadiantFaceSurfaces() {
  faceSignatures.forEach((mesh) => {
    mesh.visible = false
    mesh.userData.displayOpacity = 0
    setFaceSignatureOpacity(mesh, 0)
    if (mesh.material.map) {
      mesh.material.map = null
      mesh.material.needsUpdate = true
    }
  })
}

function applyRadiantSnapshot(faceIndex) {
  const snapshot = radiantSnapshots.get(faceIndex)
  const mesh = faceSignatures[faceIndex]
  if (!snapshot || !mesh) return false
  const texture = new THREE.CanvasTexture(snapshot)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.minFilter = THREE.LinearFilter
  texture.magFilter = THREE.LinearFilter
  texture.generateMipmaps = false
  if (radiantTexture) radiantTexture.dispose()
  radiantTexture = texture
  radiantCanvas = snapshot
  radiantOutputCanvas = snapshot
  radiantOutputCtx = snapshot.getContext('2d')
  mesh.material.map = texture
  mesh.material.needsUpdate = true
  return true
}

function destroyRadiantEffect({ keepSnapshot = false } = {}) {
  radiantLoadToken += 1
  radiantCanvas = null
  radiantOutputCanvas = null
  radiantOutputCtx = null
  radiantCustomEffect = null
  if (radiantTexture) {
    radiantTexture.dispose()
    radiantTexture = null
  }
  radiantHost.replaceChildren()
  if (!keepSnapshot) clearRadiantFaceSurfaces()
  radiantActiveFace = -1
  renderScene()
}

function waitForRadiantCanvas(iframe, timeout = 2200) {
  return new Promise((resolve, reject) => {
    const started = performance.now()
    const probe = () => {
      try {
        const canvas = iframe.contentDocument?.querySelector('canvas')
        if (canvas && canvas.width > 8 && canvas.height > 8) {
          requestAnimationFrame(() => requestAnimationFrame(() => resolve(canvas)))
          return
        }
      } catch (_) {}
      if (performance.now() - started > timeout) {
        reject(new Error('Radiant canvas initialization timeout'))
        return
      }
      requestAnimationFrame(probe)
    }
    probe()
  })
}


async function preloadRadiantEffects(onProgress = () => {}) {
  onProgress(0)
  await new Promise((resolve) => setTimeout(resolve, 120))
  onProgress(100)
}

function ensureRadiantEffect(faceIndex) {
  if (faceIndex < 0 || faceIndex >= RADIANT_EFFECT_FILES.length) {
    destroyRadiantEffect()
    return
  }
  if (radiantActiveFace === faceIndex && radiantCanvas && radiantTexture) return

  destroyRadiantEffect()
  radiantActiveFace = faceIndex
  const token = ++radiantLoadToken

  if (CUSTOM_FACE_EFFECTS.has(faceIndex)) {
    attachCustomFaceEffect(faceIndex)
    wakeFaceSignature(900)
    renderScene()
    return
  }

  // Snapshot is visible immediately, so the physical face never falls back to grey.
  applyRadiantSnapshot(faceIndex)

  const iframe = document.createElement('iframe')
  iframe.className = 'radiant-effect-frame'
  iframe.tabIndex = -1
  iframe.loading = 'eager'
  iframe.title = ''
  const cachedSource = radiantSources.get(faceIndex)
  if (cachedSource) iframe.srcdoc = injectRadiantBase(cachedSource, faceIndex)
  else iframe.src = `/radiant/${RADIANT_EFFECT_FILES[faceIndex]}`
  radiantHost.appendChild(iframe)

  iframe.addEventListener('load', async () => {
    if (token !== radiantLoadToken || radiantActiveFace !== faceIndex) return
    try {
      const sourceCanvas = await waitForRadiantCanvas(iframe)
      if (faceIndex === 4) await new Promise((resolve) => setTimeout(resolve, 120))
      if (token !== radiantLoadToken || radiantActiveFace !== faceIndex) return
      radiantCanvas = sourceCanvas
      radiantOutputCanvas = document.createElement('canvas')
      colorizeRadiantCanvas(sourceCanvas, radiantOutputCanvas, faceIndex, performance.now())
      radiantOutputCtx = radiantOutputCanvas.getContext('2d')
      const texture = new THREE.CanvasTexture(radiantOutputCanvas)
      texture.colorSpace = THREE.SRGBColorSpace
      texture.minFilter = THREE.LinearFilter
      texture.magFilter = THREE.LinearFilter
      texture.generateMipmaps = false
      if (radiantTexture) radiantTexture.dispose()
      radiantTexture = texture
      const mesh = faceSignatures[faceIndex]
      if (!mesh) return
      mesh.material.map = texture
      mesh.material.needsUpdate = true
      wakeFaceSignature(900)
      renderScene()
    } catch (error) {
      console.warn('Radiant face effect could not be attached:', error)
    }
  }, { once: true })
}

function setFaceSignatureOpacity(mesh, opacity) {
  const value = THREE.MathUtils.clamp(opacity, 0, 1)
  mesh.userData.renderOpacity = value
  mesh.material.opacity = value
}

faces.forEach((face, index) => {
  const material = new THREE.MeshBasicMaterial({
    map: null,
    color: 0xffffff,
    transparent: true,
    opacity: 0,
    depthTest: true,
    depthWrite: false,
    side: THREE.FrontSide,
    blending: THREE.NormalBlending,
    toneMapped: false
  })
  const mesh = new THREE.Mesh(FACE_SIGNATURE_PLANE, material)
  const transform = faceTransforms[index]
  const quaternion = new THREE.Quaternion().setFromEuler(new THREE.Euler(...transform.rotation))
  const localOffset = new THREE.Vector3(0, 0, LABEL_OFFSET * 1.3).applyQuaternion(quaternion)
  mesh.position.set(transform.position[0] + localOffset.x, transform.position[1] + localOffset.y, transform.position[2] + localOffset.z)
  mesh.rotation.set(...transform.rotation)
  mesh.renderOrder = 1
  mesh.visible = false
  mesh.userData.signatureIndex = index
  mesh.userData.displayOpacity = 0
  mesh.userData.renderOpacity = 0
  faceSignatures.push(mesh)
  cubeGroup.add(mesh)
})

const STATE_TO_SIGNATURE_FACE = { 1: 1, 2: 4, 3: 0, 4: 5, 5: 2, 6: 3 }


function updateFlashlightFromPointer(event) {
  const mobile = window.innerWidth <= 720
  if (mobile || insideSection || isAnimating || hyperBlend > 0.14) {
    clearFlashlightPointer(false)
    return
  }
  const rect = canvas.getBoundingClientRect()
  cubePointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  cubePointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
  cubeRaycaster.setFromCamera(cubePointer, camera)
  const hits = cubeRaycaster.intersectObjects(faceMeshes, false)
  if (!hits.length) {
    clearFlashlightPointer(false)
    return
  }
  const hit = hits[0]
  const faceIndex = faceMeshes.indexOf(hit.object)
  if (faceIndex < 0) {
    clearFlashlightPointer(false)
    return
  }
  flashlightState.hoveredFaceIndex = faceIndex
  flashlightState.active = true
  flashlightState.localPoint.copy(hit.object.worldToLocal(hit.point.clone()))
  if (flashlightState.easedPoint.lengthSq() === 0 && flashlightState.lastMoveAt === 0) {
    flashlightState.easedPoint.copy(flashlightState.localPoint)
  }
  flashlightState.lastMoveAt = performance.now()
  wakeFaceSignature(900)
}

function clearFlashlightPointer(wake = true) {
  flashlightState.active = false
  flashlightState.hoveredFaceIndex = -1
  flashlightState.lastMoveAt = performance.now()
  if (wake) wakeFaceSignature(700)
}

function updateFaceTiles(now = performance.now()) {
  const allowed = !insideSection && !isAnimating && hyperBlend <= 0.14
  const mobile = window.innerWidth <= 720
  const activeFace = allowed && !mobile && flashlightState.active ? flashlightState.hoveredFaceIndex : -1
  if (flashlightState.active) {
    flashlightState.easedPoint.lerp(flashlightState.localPoint, 0.18)
  }

  let dirty = false
  const tmpColor = new THREE.Color()
  const faceColor = new THREE.Color()

  interactiveFaceTiles.forEach((entry, faceIndex) => {
    const faceActive = faceIndex === activeFace
    entry.group.visible = !insideSection && hyperBlend <= 0.18
    const baseFace = faceMeshes[faceIndex]
    const emissiveStrength = faceActive ? 0.14 : 0
    faceColor.copy(entry.color)
    baseFace.material.emissive.copy(faceColor).multiplyScalar(emissiveStrength)

    entry.tiles.forEach((tile) => {
      const data = tile.userData
      let targetRotX = 0
      let targetRotY = 0
      let targetLift = 0
      let targetOpacity = 0
      let targetBrightness = 0

      if (faceActive) {
        const dx = flashlightState.easedPoint.x - data.basePosition.x
        const dy = flashlightState.easedPoint.y - data.basePosition.y
        const distance = Math.sqrt(dx * dx + dy * dy)
        let influence = 1 - distance / (CUBE_SIZE * 0.78)
        influence = THREE.MathUtils.clamp(influence, 0, 1)
        influence = Math.pow(influence, 1.7)
        targetRotX = THREE.MathUtils.clamp((-dy / CUBE_SIZE) * 1.2 * influence, -FACE_TILE_MAX_TILT, FACE_TILE_MAX_TILT)
        targetRotY = THREE.MathUtils.clamp((dx / CUBE_SIZE) * 1.2 * influence, -FACE_TILE_MAX_TILT, FACE_TILE_MAX_TILT)
        targetLift = influence * 0.16
        targetOpacity = FACE_TILE_BASE_OPACITY + influence * (FACE_TILE_MAX_OPACITY - FACE_TILE_BASE_OPACITY)
        targetBrightness = influence * 0.5
      }

      data.currentRotX = THREE.MathUtils.lerp(data.currentRotX, targetRotX, faceActive ? 0.16 : 0.11)
      data.currentRotY = THREE.MathUtils.lerp(data.currentRotY, targetRotY, faceActive ? 0.16 : 0.11)
      data.currentLift = THREE.MathUtils.lerp(data.currentLift, targetLift, faceActive ? 0.17 : 0.12)
      data.currentOpacity = THREE.MathUtils.lerp(data.currentOpacity, targetOpacity, faceActive ? 0.17 : 0.12)
      data.currentBrightness = THREE.MathUtils.lerp(data.currentBrightness, targetBrightness, faceActive ? 0.18 : 0.12)

      tile.rotation.x = data.currentRotX
      tile.rotation.y = data.currentRotY
      tile.position.z = data.basePosition.z + data.currentLift
      tile.material.opacity = data.currentOpacity
      tmpColor.copy(entry.color).lerp(tileWhite, data.currentBrightness)
      tile.material.color.copy(tmpColor)

      if (
        Math.abs(data.currentRotX - targetRotX) > 0.0015 ||
        Math.abs(data.currentRotY - targetRotY) > 0.0015 ||
        Math.abs(data.currentLift - targetLift) > 0.0015 ||
        Math.abs(data.currentOpacity - targetOpacity) > 0.003
      ) dirty = true
    })
  })

  return dirty || (allowed && flashlightState.active)
}

function updateFaceSignatures(now = performance.now(), force = false) {
  if (radiantActiveFace >= 0) destroyRadiantEffect()
  clearRadiantFaceSurfaces()
  faceSignatures.forEach((mesh) => {
    mesh.visible = false
    mesh.userData.displayOpacity = 0
    setFaceSignatureOpacity(mesh, 0)
  })
  return updateFaceTiles(now)
}

function faceSignatureTick(now) {
  faceSignatureFrame = null
  const needsMore = updateFaceSignatures(now, true)
  if (needsMore) renderScene()
  if (needsMore) {
    faceSignatureFrame = requestAnimationFrame(faceSignatureTick)
  }
}

function wakeFaceSignature(duration = 850) {
  if (faceSignatureFrame == null) faceSignatureFrame = requestAnimationFrame(faceSignatureTick)
}

function syncFaceSignatureVisibility() {
  clearRadiantFaceSurfaces()
  if (radiantActiveFace >= 0) destroyRadiantEffect()
  faceSignatures.forEach((mesh) => {
    mesh.visible = false
    mesh.userData.displayOpacity = 0
    setFaceSignatureOpacity(mesh, 0)
  })
  wakeFaceSignature(600)
}

// Внутренние пространства разделов. Один и тот же куб используется как оболочка,
// а контент внутренних граней перестраивается под выбранный раздел.
const FACE_SLOTS = [
  { faceIndex: 1, rotation: [0, 90, 0] },
  { faceIndex: 4, rotation: [0, 0, 0] },
  { faceIndex: 0, rotation: [0, -90, 0] },
  { faceIndex: 5, rotation: [0, 180, 0] },
  { faceIndex: 2, rotation: [90, 0, 0] },
  { faceIndex: 3, rotation: [-90, 0, 0] }
]

function setOuterLabelHover(index) {
  if (insideSection || activeState === 0) index = -1
  if (hoveredOuterLabelIndex === index) return
  hoveredOuterLabelIndex = index
  outerFaceLabels.forEach((label, labelIndex) => {
    const face = faces[labelIndex]
    if (!face || !label.material) return
    if (label.material.map) label.material.map.dispose()
    label.material.map = makeLabelTexture(face.number, face.title, labelIndex === index)
    label.material.needsUpdate = true
  })
  updateFaceSignatures(performance.now(), true)
  if (index >= 0) wakeFaceSignature(700)
  renderScene()
}

function outerLabelIndexFromPointer(event) {
  if (insideSection) return -1
  const rect = canvas.getBoundingClientRect()
  cubePointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  cubePointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
  cubeRaycaster.setFromCamera(cubePointer, camera)
  const hits = cubeRaycaster.intersectObjects(outerFaceLabels, false)
  for (const hit of hits) {
    const labelIndex = outerFaceLabels.indexOf(hit.object)
    if (labelIndex < 0 || !hit.uv) continue
    const u = hit.uv.x
    const v = hit.uv.y
    const wordCount = faces[labelIndex].title.trim().split(/\s+/).length
    const minV = wordCount > 1 ? 0.33 : 0.41
    const maxV = wordCount > 1 ? 0.67 : 0.59
    if (u >= 0.14 && u <= 0.86 && v >= minV && v <= maxV) return labelIndex
  }
  return -1
}

// Physical face -> outer section mapping. Used for direct clicks on the cube.
const FACE_TO_STATE = { 0: 3, 1: 1, 2: 5, 3: 6, 4: 2, 5: 4 }
const FACE_TO_INNER_INDEX = new Map(FACE_SLOTS.map((slot, index) => [slot.faceIndex, index]))


let projectPortfolio = {
  0: [
    ['LUXEMOTORS WEBSITE', '/projects/luxemotors-website.webp'],
    ['PATENTMARKET WEBSITE', '/projects/patentmarket.webp'],
    ['NATASHASVENSON WEBSITE', '/projects/natashasvenson.webp'],
    ['SMARTLINE WEBSITE', '/projects/smartline.webp'],
    ['KRASGLASS WEBSITE', '/projects/krasglass.webp'],
    ['KAMENKI WEBSITE', '/projects/kamenki.webp'],
    ['JETPACKAVIATION WEBSITE', '/projects/jetpackaviation.webp'],
    ['BELRUS WEBSITE', '/projects/belrus.webp'],
    ['FLYASIA WEBSITE', '/projects/flyasia.webp'],
    ['EUROPEAN ORGANICS WEBSITE', '/projects/european-organics.webp'],
    ['ARKHIGRAD WEBSITE', '/projects/arkhigrad.webp'],
    ['TRANSMET WEBSITE', '/projects/transmet.webp']
  ],
  1: [
    ['REDROOM IDENTITY', '/projects/redroom.webp'],
    ['LUXEMOTORS IDENTITY', '/projects/luxemotors-identity.webp'],
    ['COOLSCHOOL IDENTITY', '/projects/coolschool.webp'],
    ['TECSMA BRANDING & IDENTITY', '/projects/tecsma-identity.webp'],
    ['ZIMA IDENTITY', '/projects/zima.webp'],
    ['VERANDA IDENTITY', '/projects/veranda.webp']
  ],
  2: [
    ['TECSMA WEBSITE LAYOUTS', '/projects/tecsma-layouts.webp'],
    ['LABELRATE WEBSITE', '/projects/labelrate.webp']
  ],
  3: [
    ['ENDURO24', '/projects/enduro24.webp']
  ],
  4: [
    ['ALMAZ SWEETBOX NEW YEAR DESIGN', '/projects/almaz.webp'],
    ['MEDIA PRINT DESIGN / 01', '/projects/media-print-1.webp'],
    ['MEDIA PRINT DESIGN / 02', '/projects/media-print-2.webp']
  ],
  5: []
}

const sectionSpaces = {
  1: {
    key: 'services',
    title: 'УСЛУГИ',
    eyebrow: 'УСЛУГИ / ВХОД ВНУТРЬ',
    innerLabel: 'УСЛУГИ / ВНУТРИ КУБА',
    items: [
      ['01', 'РАЗРАБОТКА САЙТОВ', 'Корпоративные сайты, промо, спецпроекты и сложные веб-интерфейсы.'],
      ['02', 'E-COMMERCE', 'Интернет-магазины, каталоги, продуктовые витрины и commerce-системы.'],
      ['03', 'ИНТЕРФЕЙСЫ / APP', 'Интерфейсы сервисов, кабинетов, приложений и внутренних продуктов.'],
      ['04', 'ИНТЕГРАЦИИ', 'Модули, API, автоматизация процессов и связь цифровых систем.'],
      ['05', 'ПОДДЕРЖКА', 'Развитие, сопровождение, аналитика, оптимизация и продвижение.'],
      ['06', 'ДИЗАЙН / БРЕНДИНГ', 'Айдентика, визуальные системы, дизайн коммуникаций и носителей.']
    ]
  },
  2: {
    key: 'projects',
    title: 'ПРОЕКТЫ',
    eyebrow: 'ПРОЕКТЫ / РУБРИКИ',
    innerLabel: 'ПРОЕКТЫ / ВНУТРИ КУБА',
    items: [
      ['01', 'САЙТЫ', 'Корпоративные сайты, промо-сайты и цифровые спецпроекты.'],
      ['02', 'АЙДЕНТИКА', 'Бренды, логотипы и визуальные системы.'],
      ['03', 'ИНТЕРФЕЙСЫ', 'Сервисы, приложения, кабинеты и продуктовые интерфейсы.'],
      ['04', 'ВИДЕО', 'Motion, презентационные ролики и визуальные истории.'],
      ['05', 'ПОЛИГРАФИЯ', 'Каталоги, буклеты, упаковка и печатные коммуникации.'],
      ['06', 'МЕРЧ', 'Предметы, одежда, сувенирные и брендированные носители.']
    ]
  },
  3: {
    key: 'company',
    title: 'КОМПАНИЯ',
    eyebrow: 'КОМПАНИЯ / РАЗДЕЛЫ',
    innerLabel: 'КОМПАНИЯ / ВНУТРИ КУБА',
    items: [
      ['01', 'О НАС', 'Кто мы, как работаем и во что верим.'],
      ['02', 'ВАКАНСИИ', 'Открытые роли, формат работы и знакомство с командой.'],
      ['03', 'КОНТАКТЫ', 'Как связаться с компанией и начать разговор.']
    ]
  },
  4: {
    key: 'lab',
    title: 'ЛАБОРАТОРИЯ',
    eyebrow: 'ЛАБОРАТОРИЯ / ЭКСПЕРИМЕНТЫ',
    innerLabel: 'LAB / EXPERIMENTAL SPACE',
    items: [
      ['01', '3D', 'Пространственные интерфейсы и WebGL-эксперименты.'],
      ['02', 'GENERATIVE', 'Генеративная графика и алгоритмические визуальные системы.'],
      ['03', 'AI', 'Эксперименты с искусственным интеллектом и новыми сценариями.'],
      ['04', 'MOTION', 'Движение, переходы и кинетические интерфейсы.'],
      ['05', 'PROTOTYPES', 'Быстрые прототипы новых цифровых продуктов.'],
      ['06', 'R&D', 'Исследования, тесты и технологии без обязательного результата.']
    ]
  },
  5: {
    key: 'shop',
    title: 'МАГАЗИН',
    eyebrow: 'МАГАЗИН / SHOWROOM',
    innerLabel: 'SHOP / SHOWROOM',
    items: [
      ['01', 'DROP 001', 'Первый экспериментальный выпуск 4ДКУБ.'],
      ['02', 'OBJECTS', 'Физические объекты и малые серии.'],
      ['03', 'PRINTS', 'Постеры, графика и печатные выпуски.'],
      ['04', 'DIGITAL', 'Цифровые продукты и коллекционные материалы.'],
      ['05', 'MERCH', 'Одежда и брендированные предметы.'],
      ['06', 'COMING SOON', 'Следующий выпуск находится в разработке.']
    ]
  },
  6: {
    key: 'contacts',
    title: 'КОНТАКТЫ',
    eyebrow: 'КОНТАКТЫ / ВХОД',
    innerLabel: 'CONTACT ROOM',
    singleRoom: true,
    items: [
      ['01', 'НАЧАТЬ ПРОЕКТ', 'Расскажите о задаче. Здесь будет форма, почта и способы связи.']
    ]
  }
}

function normalizedItems(section) {
  return section.items.map((item, index) => ({
    number: item[0], title: item[1], short: item[2],
    detail: section.key === 'services' ? (serviceDetails[index] || null) : null,
    faceIndex: FACE_SLOTS[index].faceIndex,
    rotation: FACE_SLOTS[index].rotation
  }))
}

function makeInnerTexture(item, sectionTitle) {
  const size = 768
  const c = document.createElement('canvas')
  c.width = size
  c.height = size
  const ctx = c.getContext('2d')
  ctx.clearRect(0, 0, size, size)
  ctx.fillStyle = 'rgba(255,255,255,0.48)'
  ctx.font = `600 30px ${cubeLabelFontFamily}`
  ctx.textAlign = 'left'
  ctx.textBaseline = 'top'
  ctx.fillText(item.number, 54, 50)

  const words = item.title.split(' ')
  const lines = []
  let line = ''
  for (const word of words) {
    const test = line ? `${line} ${word}` : word
    ctx.font = `700 55px ${cubeLabelFontFamily}`
    if (ctx.measureText(test).width > 570 && line) { lines.push(line); line = word } else { line = test }
  }
  if (line) lines.push(line)
  ctx.fillStyle = '#ffffff'
  ctx.font = `700 55px ${cubeLabelFontFamily}`
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  const lineGap = 68
  const startY = 330 - ((lines.length - 1) * lineGap) / 2
  lines.forEach((text, i) => ctx.fillText(text, size / 2, startY + i * lineGap))
  ctx.fillStyle = 'rgba(255,255,255,0.50)'
  ctx.font = `400 22px ${cubeLabelFontFamily}`
  ctx.fillText(`${sectionTitle} / ВНУТРЕННИЙ УРОВЕНЬ`, size / 2, 675)

  ctx.shadowBlur = 0
  ctx.shadowColor = 'transparent'

  const texture = new THREE.CanvasTexture(c)
  texture.colorSpace = THREE.SRGBColorSpace
  texture.generateMipmaps = false
  texture.minFilter = THREE.LinearFilter
  texture.magFilter = THREE.LinearFilter
  texture.wrapS = THREE.RepeatWrapping
  texture.repeat.x = -1
  texture.offset.x = 1
  return texture
}

const innerLabelGeometry = new THREE.PlaneGeometry(3.18, 3.18)
const INNER_OFFSET = 0.024
const innerLabels = []

FACE_SLOTS.forEach((slot, slotIndex) => {
  const t = faceTransforms[slot.faceIndex]
  const inward = {
    0: [-INNER_OFFSET, 0, 0], 1: [ INNER_OFFSET, 0, 0],
    2: [0, -INNER_OFFSET, 0], 3: [0, INNER_OFFSET, 0],
    4: [0, 0, -INNER_OFFSET], 5: [0, 0, INNER_OFFSET]
  }[slot.faceIndex]
  const material = new THREE.MeshBasicMaterial({ transparent: true, opacity: 1, side: THREE.BackSide, depthTest: true, depthWrite: false })
  const label = new THREE.Mesh(innerLabelGeometry, material)
  label.position.set(t.position[0] + inward[0], t.position[1] + inward[1], t.position[2] + inward[2])
  label.rotation.set(...t.rotation)
  label.renderOrder = 3
  label.visible = false
  innerLabels.push(label)
  cubeGroup.add(label)
})

function loadInnerSection(section) {
  const items = normalizedItems(section)
  innerLabels.forEach((label, index) => {
    if (label.material.map) label.material.map.dispose()
    if (index < items.length) {
      label.material.map = makeInnerTexture(items[index], section.title)
      label.material.needsUpdate = true
      label.visible = false
    } else {
      label.material.map = null
      label.material.needsUpdate = true
      label.visible = false
    }
  })
  return items
}

function updateInnerFaceVisibility() {
  const projectsRoom = currentSection && (currentSection.key === 'projects' || currentSection.key === 'services')
  innerLabels.forEach((label, index) => {
    label.visible = insideSection && !projectsRoom && index === activeInnerIndex && index < currentItems.length
    label.material.opacity = 1
  })
}

function setCubeLabelMode(mode, itemCount = 6) {
  const showInner = mode === 'inner'
  outerFaceLabels.forEach((label) => { label.visible = !showInner; label.material.opacity = 1 })
  if (showInner) faceSignatures.forEach((signature) => { signature.visible = false })
  else syncFaceSignatureVisibility()
  innerLabels.forEach((label, index) => {
    label.visible = showInner && currentSection && currentSection.key !== 'projects' && currentSection.key !== 'services' && index === activeInnerIndex && index < itemCount
    label.material.opacity = 1
  })
}

function setOuterLabelsOpacity(opacity) {
  const value = THREE.MathUtils.clamp(opacity, 0, 1)
  outerFaceLabels.forEach((label) => { if (label.visible) label.material.opacity = value })
  faceSignatures.forEach((signature) => { if (signature.visible) setFaceSignatureOpacity(signature, (signature.userData.displayOpacity ?? 0) * value) })
}
setCubeLabelMode('outer')
// Home starts as the living hypercube; the ordinary labeled cube fades in on hover.
faceMeshes.forEach((mesh) => { mesh.material.opacity = 0 })
outerFaceLabels.forEach((label) => { label.material.opacity = 0 })
faceSignatures.forEach((signature) => { setFaceSignatureOpacity(signature, 0) })
ensureHypercubeLoop()

const states = [
  { nav: 'Главная', title: '4ДКУБ', description: 'Пространственный интерфейс. Выберите направление.', status: 'СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ.', rotation: [-10, 28, 0], zoom: false },
  { nav: 'Услуги', title: 'Услуги', description: 'Разработка, дизайн, интеграции и цифровые продукты.', status: 'СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ.', rotation: [0, 90, 0], zoom: true },
  { nav: 'Проекты', title: 'Проекты', description: 'Сайты, айдентика, интерфейсы, видео, полиграфия и мерч.', status: 'СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ.', rotation: [0, 0, 0], zoom: true },
  { nav: 'Компания', title: 'Компания', description: 'О нас, вакансии и контакты компании.', status: 'СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ.', rotation: [0, -90, 0], zoom: true },
  { nav: 'Лаборатория', title: 'Лаборатория', description: '3D, generative, AI, motion, prototypes и R&D.', status: 'СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ.', rotation: [0, 180, 0], zoom: true },
  { nav: 'Магазин', title: 'Магазин', description: 'Showroom объектов, цифровых продуктов и экспериментальных выпусков.', status: 'СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ.', rotation: [90, 0, 0], zoom: true },
  { nav: 'Контакты', title: 'Контакты', description: 'Войдите в контактную комнату, чтобы начать проект.', status: 'СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ.', rotation: [-90, 0, 0], zoom: true }
]

let activeState = 0
let isAnimating = false
let ignoreFaceClicks = false
let activeAnimationFrame = null
let insideSection = false
let activeInnerIndex = 0
let currentSection = null
let currentItems = []
let homeIntroText = 'Мы компания, которая удовлетворяет потребности бизнеса и других организаций в сфере программных решений, веб-разработки, дизайна, фирменной и полиграфической продукции. Стремимся к технологическому лидерству и продвигаем инновационные достижения в индустрии, поддерживая высокие стандарты качества услуг.'
let serviceDetails = {
  0: {
    lead: 'Наш подход к созданию сайтов – дизайн информации, которая необходима вашему пользователю.',
    questions: [
      'Кто и где увидит информацию о вас?',
      'Чем привлечь внимание пользователя?',
      'Что пользователи ждут от вас?',
      'Какие действия они "должны" совершить?',
      'Чем должна закончиться коммуникация?',
      'Что запомнят о вас и расскажут другим?'
    ],
    outro: 'Неважно, точно ли вы уже определились с задачами и имеете конкретное ТЗ или только собираетесь приступить к работе, свяжитесь с нами и начните прямо сегодня',
    cta: 'Начать работу'
  },
  1: {
    lead: 'Мы делаем интернет-магазины и онлайн каталоги на любых платформах',
    questions: [
      'Кто ваша целевая аудитория?',
      'Каким образом покупатели попадут к вам?',
      'Что покупатель ждет от магазина?',
      'Что сделать чтобы покупатель остался и не ушел сразу?',
      'Какие действия они должны совершить?',
      'Чем должно закончиться посещение магазина?',
      'Кто будет управлять информацией?'
    ],
    outro: 'Неважно, точно ли вы уже определились с задачами и имеете конкретное ТЗ или только собираетесь приступить к работе, свяжитесь с нами и начните прямо сегодня',
    cta: 'Начать работу'
  }
}
const PROJECTS_PER_PAGE = 4
let currentProjectPage = 0
let projectOpened = false
let openedProject = null
let pendingOuterState = null
let cmsContentRaw = null
let cmsProjectsRaw = []

// === V10.7 ROUTING / HISTORY ===
const ROUTE_STATE_SLUGS = ['','services','projects','company','lab','shop','contacts']
let routeSyncSuspended = false
let initialRouteApplied = false

function routeSlug(value, fallback = 'item') {
  const source = String(value || '').trim().toLowerCase()
  const translit = source
    .replace(/[а-яё]/g, (char) => ({а:'a',б:'b',в:'v',г:'g',д:'d',е:'e',ё:'e',ж:'zh',з:'z',и:'i',й:'y',к:'k',л:'l',м:'m',н:'n',о:'o',п:'p',р:'r',с:'s',т:'t',у:'u',ф:'f',х:'h',ц:'c',ч:'ch',ш:'sh',щ:'sch',ъ:'',ы:'y',ь:'',э:'e',ю:'yu',я:'ya'}[char] || char))
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return translit || fallback
}

function innerRouteSlug(index = activeInnerIndex) {
  const item = currentItems[index]
  if (!item) return ''
  const predefined = {
    projects: ['websites','identity','interfaces','video','print','merch'],
    services: ['web','ecommerce','interfaces','integrations','support','branding'],
    company: ['about','vacancies','contacts'],
    lab: ['3d','generative','ai','motion','prototypes','rd'],
    shop: ['drop-001','objects','prints','digital','merch','coming-soon'],
    contacts: ['start-project']
  }
  return predefined[currentSection?.key]?.[index] || routeSlug(item.title, `item-${index + 1}`)
}

function projectRouteSlug(item = openedProject) {
  if (!item) return ''
  return routeSlug(item[4] || item[0], 'project')
}

function currentRoutePath() {
  if (projectOpened && currentSection?.key === 'projects' && openedProject) {
    return `/projects/${innerRouteSlug(activeInnerIndex)}/${projectRouteSlug(openedProject)}`
  }
  if (insideSection && currentSection) {
    return `/${currentSection.key === 'lab' ? 'lab' : currentSection.key}/${innerRouteSlug(activeInnerIndex)}`
  }
  return activeState === 0 ? '/' : `/${ROUTE_STATE_SLUGS[activeState]}`
}

function syncBrowserRoute(mode = 'push') {
  if (routeSyncSuspended || !initialRouteApplied) return
  const path = currentRoutePath()
  if (`${location.pathname}${location.search}` === path) return
  const method = mode === 'replace' ? 'replaceState' : 'pushState'
  history[method]({ cube4d: true }, '', path)
}

function stateIndexForSlug(slug) {
  const normalized = String(slug || '').toLowerCase()
  const aliases = { laboratory: 'lab', laboratorya: 'lab', store: 'shop', contact: 'contacts' }
  return ROUTE_STATE_SLUGS.indexOf(aliases[normalized] || normalized)
}

function innerIndexForSlug(section, slug) {
  if (!section) return 0
  const previousSection = currentSection
  const previousItems = currentItems
  currentSection = section
  currentItems = normalizedItems(section)
  let found = currentItems.findIndex((_, index) => innerRouteSlug(index) === slug)
  currentSection = previousSection
  currentItems = previousItems
  return found < 0 ? 0 : found
}

function waitUntilIdle(timeout = 5000) {
  return new Promise((resolve) => {
    const start = performance.now()
    const check = () => {
      if (!isAnimating || performance.now() - start > timeout) return resolve()
      requestAnimationFrame(check)
    }
    check()
  })
}

async function navigateToRoute(pathname = location.pathname) {
  const parts = String(pathname || '/').split('/').filter(Boolean).map((part) => decodeURIComponent(part).toLowerCase())
  routeSyncSuspended = true
  try {
    const stateIndex = parts.length ? stateIndexForSlug(parts[0]) : 0
    const targetState = stateIndex >= 0 ? stateIndex : 0

    if (projectOpened) {
      projectOpened = false
      openedProject = null
      openedProjectIndex = -1
      openedProjectMediaIndex = 0
      projectCase.classList.remove('visible')
      innerUiNav.classList.remove('case-open')
    }
    if (insideSection && activeState !== targetState) {
      exitSection()
      await waitUntilIdle()
    }
    if (!insideSection && activeState !== targetState) {
      animateToState(targetState)
      await waitUntilIdle()
    }
    if (targetState === 0 || parts.length < 2) return

    const section = sectionSpaces[targetState]
    if (!section) return
    const targetInner = innerIndexForSlug(section, parts[1])
    if (!insideSection) {
      enterSection(targetInner)
      await waitUntilIdle()
    } else if (activeInnerIndex !== targetInner) {
      rotateInside(targetInner)
      await waitUntilIdle()
    }

    if (section.key === 'projects' && parts[2]) {
      const list = projectPortfolio[targetInner] || []
      const projectIndex = list.findIndex((item) => projectRouteSlug(item) === parts[2])
      if (projectIndex >= 0) {
        openedProject = list[projectIndex]
        openedProjectIndex = projectIndex
        openedProjectMediaIndex = 0
        projectOpened = true
        projectGallery.classList.remove('visible')
        renderOpenedProjectCase(openedProject)
        innerUiNav.classList.add('case-open')
      }
    }
  } finally {
    routeSyncSuspended = false
  }
}

async function applyInitialRoute() {
  if (initialRouteApplied) return
  await navigateToRoute(location.pathname)
  initialRouteApplied = true
  syncBrowserRoute('replace')
}

window.addEventListener('popstate', () => { navigateToRoute(location.pathname) })

function quaternionForState(index) {
  const [x, y, z] = states[index].rotation
  return new THREE.Quaternion().setFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(x), THREE.MathUtils.degToRad(y), THREE.MathUtils.degToRad(z), 'XYZ'))
}

const BACKGROUND_MOTION = 0.28
let backgroundMotionDirection = 1
function backgroundState(index) { return backgroundForRotation(states[index].rotation) }
function backgroundForRotation(rotation) {
  const [x, y, z] = rotation
  return {
    angle: THREE.MathUtils.degToRad((y + z * 0.35) * BACKGROUND_MOTION * backgroundMotionDirection),
    shiftX: THREE.MathUtils.degToRad(y * BACKGROUND_MOTION * backgroundMotionDirection) * 0.24,
    shiftY: THREE.MathUtils.degToRad(x * BACKGROUND_MOTION * backgroundMotionDirection) * 0.18
  }
}
function quaternionForRotation(rotation) {
  const [x, y, z] = rotation
  return new THREE.Quaternion().setFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(x), THREE.MathUtils.degToRad(y), THREE.MathUtils.degToRad(z), 'XYZ'))
}

cubeGroup.quaternion.copy(quaternionForState(0))
const initialBackground = backgroundState(0)
backgroundUniforms.uAngle.value = initialBackground.angle
backgroundUniforms.uShift.value.set(initialBackground.shiftX, initialBackground.shiftY)
cubeGroup.scale.setScalar(NORMAL_SCALE)

const nav = document.createElement('nav')
nav.className = 'cube-nav'
nav.innerHTML = states.map((state, index) => `<button data-state="${index}"><span class="cube-nav__index">${String(index).padStart(2,'0')}</span><span class="cube-nav__label">${state.nav}</span></button>`).join('')
document.body.appendChild(nav)
const navButtons = [...nav.querySelectorAll('button')]
navButtons[0].classList.add('active')

// V10.9.8: one morph-control language for all front-end buttons.
// The primary cube navigation keeps its full compact-to-label morph; secondary
// buttons inherit the same capsule/radial transformation without hiding semantics.
function applyMorphControls(root = document) {
  const nodes = root.querySelectorAll ? root.querySelectorAll('button') : []
  nodes.forEach((button) => {
    if (button.classList.contains('project-gallery__page-dot')) return
    button.classList.add('morph-control')
  })
}
applyMorphControls(document)
const morphControlObserver = new MutationObserver((records) => {
  records.forEach((record) => record.addedNodes.forEach((node) => {
    if (!(node instanceof Element)) return
    if (node.matches('button') && !node.classList.contains('project-gallery__page-dot')) node.classList.add('morph-control')
    applyMorphControls(node)
  }))
})
morphControlObserver.observe(document.body, { childList: true, subtree: true })


const sectionIndexBadge = document.createElement('div')
sectionIndexBadge.className = 'section-index-badge'
document.body.appendChild(sectionIndexBadge)

const openFaceHint = document.createElement('div')
openFaceHint.className = 'open-face-hint'
openFaceHint.innerHTML = '<span>ОТКРЫТЬ</span><b>↗</b>'
document.body.appendChild(openFaceHint)
let openFaceHintTimer = null

const ambientParallax = document.createElement('div')
ambientParallax.className = 'ambient-parallax'
document.body.appendChild(ambientParallax)

function updateSectionIndexBadge() {
  if (insideSection || activeState === 0 || projectOpened) {
    sectionIndexBadge.classList.remove('visible')
    return
  }
  sectionIndexBadge.textContent = `${String(activeState).padStart(2,'0')} / 06`
  sectionIndexBadge.classList.add('visible')
}

function hideOpenFaceHint() {
  clearTimeout(openFaceHintTimer)
  openFaceHint.classList.remove('visible')
}

function showOpenFaceHint() {
  hideOpenFaceHint()
  if (insideSection || activeState === 0 || isAnimating || !sectionSpaces[activeState]) return
  openFaceHint.classList.add('visible')
  openFaceHintTimer = setTimeout(() => openFaceHint.classList.remove('visible'), 2600)
}

function pulseInterfaceContent() {
  const targets = [document.querySelector('.hero'), sectionChooser, innerUiLabel]
  targets.filter(Boolean).forEach((el) => {
    el.classList.remove('content-shift-in')
    void el.offsetWidth
    el.classList.add('content-shift-in')
  })
}

function applyCmsContent(cms) {
  if (!cms || typeof cms !== 'object') return
  if (Array.isArray(cms.states)) {
    cms.states.forEach((item, index) => {
      if (!states[index] || !item) return
      for (const key of ['nav', 'title', 'description', 'status']) {
        if (typeof item[key] === 'string') states[index][key] = item[key]
      }
    })
  }
  if (cms.sections && typeof cms.sections === 'object') {
    Object.values(sectionSpaces).forEach((section) => {
      const source = cms.sections[section.key]
      if (!source) return
      for (const key of ['title', 'eyebrow', 'innerLabel']) {
        if (typeof source[key] === 'string') section[key] = source[key]
      }
      if (Array.isArray(source.items) && source.items.length) {
        section.items = source.items.slice(0, 6).map((item, index) => [
          String(item.number || String(index + 1).padStart(2, '0')),
          String(item.title || ''),
          String(item.short || '')
        ])
        if (section.key === 'services') {
          serviceDetails = {}
          source.items.slice(0, 6).forEach((item, index) => {
            if (!item || (!item.lead && !Array.isArray(item.questions) && !item.outro && !item.cta)) return
            serviceDetails[index] = {
              lead: String(item.lead || ''),
              questions: Array.isArray(item.questions) ? item.questions.map((q) => String(q)) : [],
              outro: String(item.outro || ''),
              cta: String(item.cta || '')
            }
          })
        }
      }
    })
  }
  if (typeof cms.homeIntro === 'string' && cms.homeIntro.trim()) {
    homeIntroText = cms.homeIntro
  }
  if (cms.settings && Number.isFinite(Number(cms.settings.backgroundTheme))) {
    setBackgroundTheme(Number(cms.settings.backgroundTheme))
  }
  if (cms.settings) applyLiveVisualSettings(cms.settings)
  applyCurrentTypography(cms.settings || {})
}

function normalizedProjectMedia(project) {
  const raw = project && Array.isArray(project.media) ? project.media : []
  const media = raw.map((entry, index) => {
    if (typeof entry === 'string') return { id: `media-${index}`, src: entry, type: /\.(mp4|webm)(?:\?|#|$)/i.test(entry) ? 'video' : 'image', cover: index === 0 }
    if (!entry || typeof entry !== 'object') return null
    const src = String(entry.src || entry.path || entry.url || '')
    if (!src) return null
    return {
      id: String(entry.id || `media-${index}`),
      src,
      type: entry.type === 'video' || /\.(mp4|webm)(?:\?|#|$)/i.test(src) ? 'video' : 'image',
      cover: entry.cover === true,
      alt: String(entry.alt || '')
    }
  }).filter(Boolean)
  if (!media.length && project && project.image) {
    const src = String(project.image)
    media.push({ id: 'legacy-cover', src, type: /\.(mp4|webm)(?:\?|#|$)/i.test(src) ? 'video' : 'image', cover: true, alt: String(project.title || '') })
  }
  if (media.length && !media.some((entry) => entry.cover)) media[0].cover = true
  return media
}

function projectCoverPath(project) {
  if (!project) return ''
  const media = normalizedProjectMedia(project)
  const cover = media.find((entry) => entry.cover) || media[0]
  return String(project.image || cover?.src || '')
}

function applyCmsProjects(items) {
  if (!Array.isArray(items)) return
  const next = { 0: [], 1: [], 2: [], 3: [], 4: [], 5: [] }
  items
    .filter((item) => item && item.published !== false)
    .sort((a, b) => (Number(a.category) - Number(b.category)) || (Number(a.order || 0) - Number(b.order || 0)))
    .forEach((item) => {
      const category = Math.max(0, Math.min(5, Number(item.category) || 0))
      next[category].push([
        String(item.title || 'PROJECT'),
        projectCoverPath(item),
        String(item.description || ''),
        String(item.year || ''),
        String(item.id || ''),
        item
      ])
    })
  projectPortfolio = next
}


const DEFAULT_PAGE_TYPOGRAPHY = {
  headingSize: 48,
  bodySize: 14,
  lineHeight: 1.35,
  letterSpacing: 0,
  align: 'left'
}

function currentTypographyScopeKey() {
  if (projectOpened) return 'project-case'
  if (insideSection && currentSection) return `section:${currentSection.key}`
  if (activeState === 0) return 'home'
  return `state:${activeState}`
}

function currentTypographyScopeLabel() {
  if (projectOpened && openedProject) return `КЕЙС / ${openedProject[0]}`
  if (insideSection && currentSection) return `РАЗДЕЛ / ${currentSection.title}`
  if (activeState === 0) return 'ГЛАВНАЯ'
  return states[activeState] ? states[activeState].title.toUpperCase() : 'ТЕКУЩИЙ ЭКРАН'
}

function getTypographyScope(settings = null, key = currentTypographyScopeKey()) {
  const source = settings || cmsContentRaw?.settings || {}
  const scopes = source && typeof source.typographyScopes === 'object' ? source.typographyScopes : {}
  return { ...DEFAULT_PAGE_TYPOGRAPHY, ...(scopes[key] || {}) }
}

function applyCurrentTypography(settings = null) {
  const scope = getTypographyScope(settings)
  const root = document.documentElement
  const headingSize = THREE.MathUtils.clamp(Number(scope.headingSize) || DEFAULT_PAGE_TYPOGRAPHY.headingSize, 16, 120)
  const bodySize = THREE.MathUtils.clamp(Number(scope.bodySize) || DEFAULT_PAGE_TYPOGRAPHY.bodySize, 8, 40)
  const lineHeight = THREE.MathUtils.clamp(Number(scope.lineHeight) || DEFAULT_PAGE_TYPOGRAPHY.lineHeight, 0.85, 2.4)
  const letterSpacing = THREE.MathUtils.clamp(Number(scope.letterSpacing) || 0, -0.08, 0.3)
  const align = ['left','center','right'].includes(scope.align) ? scope.align : 'left'
  root.style.setProperty('--page-heading-size', `${headingSize}px`)
  root.style.setProperty('--page-body-size', `${bodySize}px`)
  root.style.setProperty('--page-line-height', String(lineHeight))
  root.style.setProperty('--page-letter-spacing', `${letterSpacing}em`)
  root.style.setProperty('--page-text-align', align)
}

async function loadCmsData() {
  try {
    const stamp = Date.now()
    const [contentResponse, projectsResponse] = await Promise.all([
      fetch(`/data/content.json?v=${stamp}`, { cache: 'no-store' }),
      fetch(`/data/projects.json?v=${stamp}`, { cache: 'no-store' })
    ])
    if (contentResponse.ok) {
      const contentData = await contentResponse.json()
      cmsContentRaw = contentData
      applyCmsContent(contentData)
    }
    if (projectsResponse.ok) {
      const projectsData = await projectsResponse.json()
      cmsProjectsRaw = Array.isArray(projectsData) ? projectsData : []
      applyCmsProjects(cmsProjectsRaw)
    }
    navButtons.forEach((button, index) => { const label = button.querySelector('.cube-nav__label'); if (states[index] && label) label.textContent = states[index].nav })
    updateText(activeState)
    buildSectionChooser()
    if (insideSection && currentSection) {
      currentItems = normalizedItems(currentSection)
      buildInnerUi()
      updateInnerText(activeInnerIndex)
    }
    renderProjectGallery()
    renderHomeIntro()
    renderServiceDetail()
    renderLabExperiment()
    renderScene()
  } catch (error) {
    console.warn('4ДКУБ CMS: используются встроенные данные.', error)
  }
}

const sectionChooser = document.createElement('section')
sectionChooser.className = 'section-chooser'
document.body.appendChild(sectionChooser)

const innerUi = document.createElement('div')
innerUi.className = 'inner-ui'
innerUi.innerHTML = `<button type="button" class="inner-ui__case-prev"><span>← ПРЕДЫДУЩИЙ</span><strong></strong></button><button type="button" class="inner-ui__back">ВЫЙТИ</button><button type="button" class="inner-ui__case-next"><span>СЛЕДУЮЩИЙ →</span><strong></strong></button><div class="inner-ui__label"></div><nav class="inner-ui__nav"></nav>`
document.body.appendChild(innerUi)
const innerBackButton = innerUi.querySelector('.inner-ui__back')
const cubeExitButton = document.createElement('button')
cubeExitButton.type = 'button'
cubeExitButton.className = 'cube-exit-button morph-control'
cubeExitButton.textContent = 'ВЫЙТИ'
cubeExitButton.setAttribute('aria-label', 'Выйти из куба')
cubeExitButton.hidden = true
document.body.appendChild(cubeExitButton)
const casePrevButton = innerUi.querySelector('.inner-ui__case-prev')
const caseNextButton = innerUi.querySelector('.inner-ui__case-next')
let openedProjectIndex = -1
let openedProjectMediaIndex = 0
const innerUiLabel = innerUi.querySelector('.inner-ui__label')
const innerUiNav = innerUi.querySelector('.inner-ui__nav')
const projectGallery = document.createElement('section')
projectGallery.className = 'project-gallery'
document.body.appendChild(projectGallery)

const projectCase = document.createElement('section')
projectCase.className = 'project-case case-face-content'
document.body.appendChild(projectCase)

const homeIntro = document.createElement('section')
homeIntro.className = 'home-intro'
homeIntro.textContent = homeIntroText
document.body.appendChild(homeIntro)

const serviceDetail = document.createElement('section')
serviceDetail.className = 'service-detail'
document.body.appendChild(serviceDetail)

const labExperiment = document.createElement('section')
labExperiment.className = 'lab-experiment'
document.body.appendChild(labExperiment)

const introLoader = document.createElement('div')
introLoader.className = 'cube-intro-loader'
introLoader.innerHTML = `
  <div class="cube-intro-loader__hypercube" aria-hidden="true">
    <svg viewBox="0 0 120 120" role="presentation">
      <g class="cube-intro-loader__hypercube-spin">
        <rect x="18" y="18" width="84" height="84" rx="1"></rect>
        <rect x="38" y="38" width="44" height="44" rx="1"></rect>
        <path d="M18 18 38 38M102 18 82 38M102 102 82 82M18 102 38 82"></path>
      </g>
    </svg>
  </div>
  <div class="cube-intro-loader__word">4ДКУБ</div>
  <div class="cube-intro-loader__status">СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ. <span>0%</span></div>
  <div class="cube-intro-loader__progress" aria-hidden="true"><i></i></div>`
document.body.appendChild(introLoader)
const introLoaderPercent = introLoader.querySelector('.cube-intro-loader__status span')
const introLoaderBar = introLoader.querySelector('.cube-intro-loader__progress i')

function setIntroLoaderProgress(value) {
  const progress = Math.max(0, Math.min(100, Math.round(Number(value) || 0)))
  if (introLoaderPercent) introLoaderPercent.textContent = `${progress}%`
  if (introLoaderBar) introLoaderBar.style.transform = `scaleX(${progress / 100})`
}

function finishIntroLoader() {
  if (!introLoader || introLoader.classList.contains('done')) return
  setIntroLoaderProgress(100)
  requestAnimationFrame(() => introLoader.classList.add('done'))
  setTimeout(() => introLoader.remove(), prefersReducedMotion ? 80 : 620)
}

function syncOverlayToActiveFace(element, insetRatio = 0.11) {
  if (!element || !insideSection || !currentItems[activeInnerIndex]) return
  const item = currentItems[activeInnerIndex]
  const mesh = faceMeshes[item.faceIndex]
  if (!mesh) return

  scene.updateMatrixWorld(true)
  camera.updateMatrixWorld(true)
  const corners = [
    new THREE.Vector3(-HALF,  HALF, 0),
    new THREE.Vector3( HALF,  HALF, 0),
    new THREE.Vector3( HALF, -HALF, 0),
    new THREE.Vector3(-HALF, -HALF, 0)
  ]
  const projected = corners.map((corner) => {
    const point = mesh.localToWorld(corner.clone()).project(camera)
    return {
      x: (point.x * 0.5 + 0.5) * window.innerWidth,
      y: (-point.y * 0.5 + 0.5) * window.innerHeight
    }
  })
  const minX = Math.min(...projected.map((p) => p.x))
  const maxX = Math.max(...projected.map((p) => p.x))
  const minY = Math.min(...projected.map((p) => p.y))
  const maxY = Math.max(...projected.map((p) => p.y))
  const faceWidth = Math.max(1, maxX - minX)
  const faceHeight = Math.max(1, maxY - minY)
  const inset = Math.max(24, Math.min(faceWidth, faceHeight) * insetRatio)
  element.style.left = `${minX + inset}px`
  element.style.top = `${minY + inset}px`
  element.style.width = `${Math.max(220, faceWidth - inset * 2)}px`
  element.style.height = `${Math.max(220, faceHeight - inset * 2)}px`
}

function renderHomeIntro() {
  const show = !insideSection && activeState === 0 && !isAnimating
  homeIntro.classList.toggle('visible', show)
  homeIntro.textContent = homeIntroText
}

function renderServiceDetail() {
  const show = insideSection && currentSection && currentSection.key === 'services' && !isAnimating
  serviceDetail.classList.toggle('visible', show)
  if (!show) return
  const item = currentItems[activeInnerIndex]
  const detail = item && item.detail
  if (!item || !detail) {
    serviceDetail.innerHTML = `<h2>${item ? item.title : ''}</h2><p class="service-detail__placeholder">Раздел будет наполнен позже.</p>`
    syncOverlayToActiveFace(serviceDetail, 0.105)
      return
  }
  serviceDetail.innerHTML = `
    <div class="service-sigil service-sigil--${activeInnerIndex}" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div>
    <h2>${item.title}</h2>
    ${detail.lead ? `<p class="service-detail__lead">${detail.lead}</p>` : ''}
    ${detail.questions.length ? `<div class="service-detail__eyebrow">ВМЕСТЕ С ВАМИ ОТВЕЧАЕМ НА ВОПРОСЫ:</div><ol>${detail.questions.map((q) => `<li>${q}</li>`).join('')}</ol>` : ''}
    ${detail.outro ? `<p class="service-detail__outro">${detail.outro}</p>` : ''}
    ${detail.cta ? `<button type="button" class="service-detail__cta">${detail.cta}</button>` : ''}
  `
  syncOverlayToActiveFace(serviceDetail, 0.105)
}


function labVisualMarkup(index) {
  if (index === 0) return `<div class="lab-viz lab-viz--3d"><b></b><b></b><b></b><span></span></div>`
  if (index === 1) return `<div class="lab-viz lab-viz--generative">${Array.from({length:36},(_,i)=>`<i style="--i:${i}"></i>`).join('')}</div>`
  if (index === 2) return `<div class="lab-viz lab-viz--ai"><b></b><b></b><b></b><b></b><b></b><span></span></div>`
  if (index === 3) return `<div class="lab-viz lab-viz--motion"><i></i><i></i><i></i><i></i><i></i></div>`
  if (index === 4) return `<div class="lab-viz lab-viz--prototype"><b></b><b></b><b></b><span></span><span></span></div>`
  return `<div class="lab-viz lab-viz--rd"><i></i><i></i><i></i><b></b><span></span></div>`
}

function renderLabExperiment() {
  const show = insideSection && currentSection && currentSection.key === 'lab' && !isAnimating
  labExperiment.classList.toggle('visible', show)
  if (!show) return
  const item = currentItems[activeInnerIndex]
  if (!item) return
  labExperiment.innerHTML = `
    <div class="lab-experiment__copy">
      <div class="lab-experiment__index">${item.number} / 06</div>
      <h2>${item.title}</h2>
      <p>${item.short}</p>
      <small>MOVE / TOUCH TO DISTURB</small>
    </div>
    <div class="lab-experiment__stage" data-lab-index="${activeInnerIndex}">${labVisualMarkup(activeInnerIndex)}</div>
  `
  syncOverlayToActiveFace(labExperiment, 0.075)
  const stage = labExperiment.querySelector('.lab-experiment__stage')
  if (stage) {
    const move = (event) => {
      const rect = stage.getBoundingClientRect()
      const point = event.touches ? event.touches[0] : event
      const x = THREE.MathUtils.clamp(((point.clientX - rect.left) / Math.max(1, rect.width)) * 2 - 1, -1, 1)
      const y = THREE.MathUtils.clamp(((point.clientY - rect.top) / Math.max(1, rect.height)) * 2 - 1, -1, 1)
      stage.style.setProperty('--lab-x', x.toFixed(3))
      stage.style.setProperty('--lab-y', y.toFixed(3))
    }
    stage.addEventListener('pointermove', move)
    stage.addEventListener('touchmove', move, { passive: true })
  }
}


function syncProjectGalleryToFace() {
  if (!projectGallery || !insideSection || !currentSection || currentSection.key !== 'projects' || !currentItems[activeInnerIndex]) return

  const item = currentItems[activeInnerIndex]
  const mesh = faceMeshes[item.faceIndex]
  if (!mesh) return

  scene.updateMatrixWorld(true)
  camera.updateMatrixWorld(true)

  const corners = [
    new THREE.Vector3(-HALF,  HALF, 0),
    new THREE.Vector3( HALF,  HALF, 0),
    new THREE.Vector3( HALF, -HALF, 0),
    new THREE.Vector3(-HALF, -HALF, 0)
  ]

  const projected = corners.map((corner) => {
    const point = mesh.localToWorld(corner.clone()).project(camera)
    return {
      x: (point.x * 0.5 + 0.5) * window.innerWidth,
      y: (-point.y * 0.5 + 0.5) * window.innerHeight
    }
  })

  const minX = Math.min(...projected.map((p) => p.x))
  const maxX = Math.max(...projected.map((p) => p.x))
  const minY = Math.min(...projected.map((p) => p.y))
  const maxY = Math.max(...projected.map((p) => p.y))

  const faceWidth = Math.max(1, maxX - minX)
  const faceHeight = Math.max(1, maxY - minY)
  const inset = Math.max(24, Math.min(faceWidth, faceHeight) * 0.095)

  const left = minX + inset
  const top = minY + inset
  const width = Math.max(220, faceWidth - inset * 2)
  const height = Math.max(220, faceHeight - inset * 2)

  // The header and pagination consume vertical space. The 2x2 grid itself stays square.
  const headReserve = 34
  const paginationReserve = 28
  const gridSize = Math.max(180, Math.min(width, height - headReserve - paginationReserve))

  projectGallery.style.setProperty('--project-left', `${left}px`)
  projectGallery.style.setProperty('--project-top', `${top}px`)
  projectGallery.style.setProperty('--project-width', `${width}px`)
  projectGallery.style.setProperty('--project-height', `${height}px`)
  projectGallery.style.setProperty('--project-grid-size', `${gridSize}px`)
}

function renderProjectGallery() {
  const show = insideSection && currentSection && currentSection.key === 'projects' && !isAnimating && !projectOpened
  projectGallery.classList.toggle('visible', show)
  projectCase.classList.toggle('visible', projectOpened && !isAnimating)
  innerUiNav.classList.toggle('case-open', projectOpened)
  if (projectOpened && !isAnimating) {
    syncOverlayToActiveFace(projectCase, 0.03)
  }
  if (!show) return

  const items = projectPortfolio[activeInnerIndex] || []
  const category = currentItems[activeInnerIndex]

  if (!items.length) {
    projectGallery.innerHTML = `<div class="project-gallery__empty"><span>${category ? category.number : '06'}</span><strong>МЕРЧ</strong><small>Пока в Dribbble-профиле нет отдельной работы для этой рубрики.</small></div>`
      return
  }

  const totalPages = Math.max(1, Math.ceil(items.length / PROJECTS_PER_PAGE))
  currentProjectPage = Math.max(0, Math.min(currentProjectPage, totalPages - 1))
  const startIndex = currentProjectPage * PROJECTS_PER_PAGE
  const visibleItems = items.slice(startIndex, startIndex + PROJECTS_PER_PAGE)

  projectGallery.innerHTML = `
    <div class="project-gallery__head">
      <span>4ДКУБ / PORTFOLIO</span>
      <strong>${category ? category.title : 'ПРОЕКТЫ'}</strong>
      <em>${String(items.length).padStart(2,'0')}</em>
    </div>
    <div class="project-gallery__grid">${visibleItems.map((item, index) => `
      <article class="project-card">
        <div class="project-card__image">${projectCardMediaMarkup(item)}</div>
        <div class="project-card__meta">
          <span>${String(startIndex + index + 1).padStart(2,'0')}</span>
          <strong><span class="project-card__title">${item[0]}</span>${item[3] ? `<small>${item[3]}</small>` : ''}</strong>
        </div>
      </article>
    `).join('')}</div>
    ${totalPages > 1 ? `<div class="project-gallery__pagination"><button type="button" class="project-gallery__page-arrow" data-project-dir="-1" aria-label="Предыдущая страница" ${currentProjectPage === 0 ? 'disabled' : ''}>←</button><div class="project-gallery__page-dots">${Array.from({ length: totalPages }, (_, pageIndex) => `<button type="button" class="project-gallery__page-dot ${pageIndex === currentProjectPage ? 'active' : ''}" data-project-page="${pageIndex}" aria-label="Страница ${pageIndex + 1}"></button>`).join('')}</div><button type="button" class="project-gallery__page-arrow" data-project-dir="1" aria-label="Следующая страница" ${currentProjectPage === totalPages - 1 ? 'disabled' : ''}>→</button></div>` : ''}
  `

  projectGallery.querySelectorAll('.project-card').forEach((card, index) => {
    card.addEventListener('click', () => {
      const item = visibleItems[index]
      if (!item) return
      openedProject = item
      openedProjectIndex = items.indexOf(item)
      openedProjectMediaIndex = 0
      projectOpened = true
      projectGallery.classList.remove('visible')
      renderOpenedProjectCase(item)
      innerUiNav.classList.add('case-open')
    })
  })

  projectGallery.querySelectorAll('[data-project-page]').forEach((button) => {
    button.addEventListener('click', () => {
      currentProjectPage = Number(button.dataset.projectPage) || 0
      renderProjectGallery()
    })
  })
  projectGallery.querySelectorAll('[data-project-dir]').forEach((button) => {
    button.addEventListener('click', () => {
      const next = currentProjectPage + Number(button.dataset.projectDir || 0)
      currentProjectPage = Math.max(0, Math.min(totalPages - 1, next))
      renderProjectGallery()
    })
  })
  syncProjectGalleryToFace()
}

const membraneFx = document.createElement('div')
membraneFx.className = 'membrane-fx'
document.body.appendChild(membraneFx)
let membraneTimer = null
function fireMembrane(direction = 'in') {
  if (membraneTimer) clearTimeout(membraneTimer)
  membraneFx.classList.remove('active', 'in', 'out')
  void membraneFx.offsetWidth
  membraneFx.classList.add('active', direction)
  membraneTimer = setTimeout(() => membraneFx.classList.remove('active', 'in', 'out'), prefersReducedMotion ? 120 : 420)
}

function setActiveFaceGlow(strength) {
  const faceIndex = currentSection && currentSection.entryFaceIndex != null ? currentSection.entryFaceIndex : states[activeState] ? ({1:1,2:4,3:0,4:5,5:2,6:3}[activeState]) : 4
  const mesh = faceMeshes[faceIndex]
  if (!mesh) return
  mesh.material.opacity = FACE_OPACITY + 0.20 * strength
  mesh.material.shininess = 72 + 70 * strength
}

const backgroundThemes = [
  { name: 'Базовый тёмный', value: 0, lightUi: false, motion: 1 }, { name: 'Светлый', value: 1, lightUi: true, motion: 1 },
  { name: 'Почти белый', value: 2, lightUi: true, motion: 1 }, { name: 'Серо-синий', value: 3, lightUi: false, motion: 1 },
  { name: 'Фиолетовый', value: 4, lightUi: false, motion: 1 }, { name: 'Без тёмных краёв', value: 5, lightUi: false, motion: 1 },
  { name: 'Без виньетки', value: 6, lightUi: false, motion: 1 }, { name: 'Яркий центр', value: 7, lightUi: false, motion: 1 },
  { name: 'Цветные пятна', value: 8, lightUi: false, motion: 1 }, { name: 'Другое движение', value: 9, lightUi: false, motion: -1 }
]
let currentBackgroundTheme = 0

function setBackgroundTheme(index) {
  const safeIndex = Math.max(0, Math.min(backgroundThemes.length - 1, Number(index) || 0))
  const theme = backgroundThemes[safeIndex]
  currentBackgroundTheme = safeIndex
  backgroundUniforms.uTheme.value = theme.value
  backgroundMotionDirection = theme.motion
  document.body.classList.toggle('light-background', theme.lightUi)
  const target = insideSection && currentItems[activeInnerIndex] ? backgroundForRotation(currentItems[activeInnerIndex].rotation) : backgroundState(activeState)
  backgroundUniforms.uAngle.value = target.angle
  backgroundUniforms.uShift.value.set(target.shiftX, target.shiftY)
  renderScene()
}


function updateText(index) {
  applyCurrentTypography()
  const state = states[index]
  if (heroTitle) heroTitle.textContent = state.title
  if (heroText) heroText.textContent = state.description
  if (statusText) statusText.textContent = state.status
}
function updateInnerText(index) {
  applyCurrentTypography()
  const item = currentItems[index]
  if (!item) return
  if (heroTitle) heroTitle.textContent = currentSection.title
  if (heroText) heroText.textContent = states[activeState] ? states[activeState].description : currentSection.title
  if (statusText) statusText.textContent = 'СЛОЖНЫЕ ВЕЩИ В ПРОСТОЙ ФОРМЕ.'
}

function buildSectionChooser() {
  const section = sectionSpaces[activeState]
  if (!section) { sectionChooser.innerHTML = ''; return }
  currentSection = section
  currentItems = normalizedItems(section)
  sectionChooser.innerHTML = `<div class="section-chooser__eyebrow">${section.eyebrow}</div><div class="section-chooser__list">${currentItems.map((item,index)=>`<button type="button" data-entry="${index}"><span>${item.number}</span><strong>${item.title}</strong></button>`).join('')}</div>`
  sectionChooser.querySelectorAll('[data-entry]').forEach(button => button.addEventListener('click', () => enterSection(Number(button.dataset.entry))))
}

function buildInnerUi() {
  innerUiLabel.textContent = currentSection.innerLabel
  innerUiNav.innerHTML = currentSection.singleRoom ? '' : currentItems.map((item,index)=>`<button type="button" data-inner="${index}"><span>${item.number}</span><strong>${item.title}</strong></button>`).join('')
  innerUiNav.querySelectorAll('[data-inner]').forEach(button => button.addEventListener('click', () => rotateInside(Number(button.dataset.inner))))
}

function syncCompositionMode() {
  const hasSection = !!sectionSpaces[activeState]
  const mode = projectOpened
    ? 'case'
    : insideSection
      ? 'inside'
      : (activeState !== 0 && hasSection ? 'select' : 'home')
  document.body.dataset.mobileMode = mode
  document.body.classList.toggle('mobile-home', mode === 'home')
  document.body.classList.toggle('mobile-select', mode === 'select')
  document.body.classList.toggle('mobile-inside', mode === 'inside')
  document.body.classList.toggle('mobile-case', mode === 'case')
}

function syncModeUi() {
  const hasSection = !!sectionSpaces[activeState]
  sectionChooser.classList.toggle('visible', !insideSection && hasSection && activeState !== 0 && !isAnimating)
  innerUi.classList.toggle('visible', insideSection)
  innerBackButton.hidden = true
  innerBackButton.style.display = 'none'
  cubeExitButton.hidden = !insideSection
  cubeExitButton.classList.toggle('visible', insideSection)
  nav.classList.toggle('hidden', insideSection)
  innerUiNav.querySelectorAll('[data-inner]').forEach((button, index) => button.classList.toggle('active', index === activeInnerIndex))
  syncCompositionMode()
  updateInnerFaceVisibility()
  renderProjectGallery()
  renderHomeIntro()
  renderServiceDetail()
  renderLabExperiment()
}

updateText(0)
buildSectionChooser()
syncModeUi()
Promise.allSettled([
  loadCmsData(),
  preloadRadiantEffects(setIntroLoaderProgress)
]).finally(() => {
  applyInitialRoute()
  setTimeout(finishIntroLoader, prefersReducedMotion ? 40 : 220)
})

function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3) }
function easeInOutCubic(t) { return t < 0.5 ? 4*t*t*t : 1 - Math.pow(-2*t + 2, 3)/2 }
function renderScene() { if (document.visibilityState === 'visible') renderer.render(scene, camera) }
function lerpScale(from, to, t) { cubeGroup.scale.setScalar(THREE.MathUtils.lerp(from, to, t)) }
function animateBackground(from, to, t) {
  backgroundUniforms.uAngle.value = THREE.MathUtils.lerp(from.angle, to.angle, t)
  backgroundUniforms.uShift.value.set(THREE.MathUtils.lerp(from.shiftX, to.shiftX, t), THREE.MathUtils.lerp(from.shiftY, to.shiftY, t))
}

function finishTransition(nextState) {
  activeState = nextState
  isAnimating = false
  setTimeout(() => { ignoreFaceClicks = false }, 250)
  activeAnimationFrame = null
  navButtons.forEach((button) => { button.disabled = false })
  buildSectionChooser()
  syncModeUi()
  updateSectionIndexBadge()
  if (nextState !== 0) {
    showOpenFaceHint()
    wakeFaceSignature()
  } else {
    destroyRadiantEffect()
    clearRadiantFaceSurfaces()
  }
  pulseInterfaceContent()
  if (nextState === 0 && !hyperPointerOver) {
    hyperTarget = 1
    ensureHypercubeLoop()
  } else {
    hyperBlend = 0
    hyperTarget = 0
    applyHyperBlend()
  }
  renderScene()
  syncBrowserRoute()
}

function animateToState(nextState) {
  if (isAnimating || insideSection || nextState === activeState) return
  hideOpenFaceHint()
  // Effects belong only to a stable selected face. Remove them before the cube starts moving.
  destroyRadiantEffect()
  clearRadiantFaceSurfaces()
  // Navigation always works with the stable ordinary cube, never with the moving hypercube.
  hyperBlend = 0
  hyperTarget = 0
  applyHyperBlend()
  isAnimating = true
  ignoreFaceClicks = true
  projectGallery.classList.remove('visible')
  serviceDetail.classList.remove('visible')
  labExperiment.classList.remove('visible')
  homeIntro.classList.remove('visible')
  sectionChooser.classList.remove('visible')
  navButtons.forEach((button,index)=>{ button.classList.toggle('active', index===nextState); button.disabled=true })
  const startQuat = cubeGroup.quaternion.clone(), targetQuat = quaternionForState(nextState)
  const bgStart = { angle: backgroundUniforms.uAngle.value, shiftX: backgroundUniforms.uShift.value.x, shiftY: backgroundUniforms.uShift.value.y }
  const bgTarget = backgroundState(nextState)
  const startScale = cubeGroup.scale.x, start = performance.now(), duration = prefersReducedMotion ? 120 : 520
  let textUpdated = false
  function tick(now) {
    const raw = Math.min((now-start)/duration,1), t = easeInOutCubic(raw)
    cubeGroup.quaternion.slerpQuaternions(startQuat,targetQuat,t); animateBackground(bgStart,bgTarget,t); lerpScale(startScale,NORMAL_SCALE,t); renderScene()
    if (!textUpdated && raw>=.48) { updateText(nextState); textUpdated=true }
    if (raw<1) return activeAnimationFrame=requestAnimationFrame(tick)
    cubeGroup.quaternion.copy(targetQuat)
    cubeGroup.scale.setScalar(NORMAL_SCALE)
    finishTransition(nextState)
  }
  activeAnimationFrame=requestAnimationFrame(tick)
}

function enterSection(index) {
  if (isAnimating || insideSection || !sectionSpaces[activeState]) return
  hideOpenFaceHint()
  sectionIndexBadge.classList.remove('visible')
  currentSection = sectionSpaces[activeState]
  currentItems = loadInnerSection(currentSection)
  buildInnerUi()
  activeInnerIndex = Math.min(index, currentItems.length - 1)
  currentProjectPage = 0
  isAnimating = true
  homeIntro.classList.remove('visible')
  serviceDetail.classList.remove('visible')
  labExperiment.classList.remove('visible')
  sectionChooser.classList.remove('visible')
  navButtons.forEach(b=>b.disabled=true)

  const startZ=camera.position.z, faceZ=HALF*FACE_SCALE, preZ=faceZ+.48, crossedZ=faceZ-.42
  const aStart=performance.now(), aDur=prefersReducedMotion ? 120 : 460
  function approach(now){
    const raw=Math.min((now-aStart)/aDur,1), t=easeInOutCubic(raw)
    camera.position.z=THREE.MathUtils.lerp(startZ,preZ,t)
    setOuterLabelsOpacity(raw<.42?1:1-((raw-.42)/.58)); renderScene()
    if(raw<1)return activeAnimationFrame=requestAnimationFrame(approach)
    const cStart=performance.now(), cDur=prefersReducedMotion ? 80 : 170; let fired=false
    function cross(now2){
      const r=Math.min((now2-cStart)/cDur,1), t2=easeInOutCubic(r)
      camera.position.z=THREE.MathUtils.lerp(preZ,crossedZ,t2)
      const strength=Math.max(0,1-Math.abs(r-.52)/.50); setActiveFaceGlow(strength*.62)
      if(!fired && r>=.38){ fired=true; fireMembrane('in') }
      renderScene()
      if(r<1)return activeAnimationFrame=requestAnimationFrame(cross)
      setActiveFaceGlow(0); setOuterLabelsOpacity(0)
      const sStart=performance.now(), sDur=prefersReducedMotion ? 90 : 210
      function settle(now3){
        const rr=Math.min((now3-sStart)/sDur,1), tt=easeOutCubic(rr); camera.position.z=THREE.MathUtils.lerp(crossedZ,0,tt); renderScene()
        if(rr<1)return activeAnimationFrame=requestAnimationFrame(settle)
        camera.position.z=0; setCubeLabelMode('inner', currentItems.length)
        const turnStart=performance.now(), turnDur=prefersReducedMotion ? 120 : 420
        const startQuat=cubeGroup.quaternion.clone(), targetQuat=quaternionForRotation(currentItems[activeInnerIndex].rotation)
        const bgS={angle:backgroundUniforms.uAngle.value,shiftX:backgroundUniforms.uShift.value.x,shiftY:backgroundUniforms.uShift.value.y}, bgT=backgroundForRotation(currentItems[activeInnerIndex].rotation)
        function turn(now4){
          const r4=Math.min((now4-turnStart)/turnDur,1), t4=easeInOutCubic(r4)
          camera.rotation.y=THREE.MathUtils.lerp(0,Math.PI,t4); camera.position.z=THREE.MathUtils.lerp(0,INNER_CAMERA_Z,t4); camera.fov=THREE.MathUtils.lerp(responsiveOuterFov(),responsiveInnerFov(),t4); camera.updateProjectionMatrix()
          cubeGroup.scale.setScalar(THREE.MathUtils.lerp(FACE_SCALE,NORMAL_SCALE,t4)); cubeGroup.quaternion.slerpQuaternions(startQuat,targetQuat,t4); animateBackground(bgS,bgT,t4); renderScene()
          if(r4<1)return activeAnimationFrame=requestAnimationFrame(turn)
          camera.rotation.y=Math.PI; camera.position.z=INNER_CAMERA_Z; camera.fov=responsiveInnerFov(); camera.updateProjectionMatrix(); cubeGroup.scale.setScalar(NORMAL_SCALE); cubeGroup.quaternion.copy(targetQuat)
          insideSection=true; isAnimating=false; activeAnimationFrame=null; currentProjectPage = 0; updateInnerText(activeInnerIndex); syncModeUi(); renderScene(); syncBrowserRoute()
        }
        activeAnimationFrame=requestAnimationFrame(turn)
      }
      activeAnimationFrame=requestAnimationFrame(settle)
    }
    activeAnimationFrame=requestAnimationFrame(cross)
  }
  activeAnimationFrame=requestAnimationFrame(approach)
}

function rotateInside(index) {
  if (isAnimating || !insideSection || index===activeInnerIndex || !currentItems[index]) return
  currentProjectPage = 0
  isAnimating=true
  innerLabels.forEach(label => label.visible = false)
  projectGallery.classList.remove('visible')
  serviceDetail.classList.remove('visible')
  labExperiment.classList.remove('visible')
  const startQuat=cubeGroup.quaternion.clone(), targetQuat=quaternionForRotation(currentItems[index].rotation)
  const bgS={angle:backgroundUniforms.uAngle.value,shiftX:backgroundUniforms.uShift.value.x,shiftY:backgroundUniforms.uShift.value.y}, bgT=backgroundForRotation(currentItems[index].rotation)
  const start=performance.now(), duration=prefersReducedMotion ? 120 : 420
  function tick(now){ const r=Math.min((now-start)/duration,1), t=easeInOutCubic(r); cubeGroup.quaternion.slerpQuaternions(startQuat,targetQuat,t); animateBackground(bgS,bgT,t); renderScene(); if(r<1)return activeAnimationFrame=requestAnimationFrame(tick); activeInnerIndex=index; cubeGroup.quaternion.copy(targetQuat); isAnimating=false; activeAnimationFrame=null; updateInnerText(index); syncModeUi(); renderScene(); syncBrowserRoute() }
  activeAnimationFrame=requestAnimationFrame(tick)
}

function exitSection() {
  if (isAnimating || !insideSection) return
  isAnimating=true; innerUi.classList.remove('visible'); projectGallery.classList.remove('visible'); projectCase.classList.remove('visible'); serviceDetail.classList.remove('visible'); labExperiment.classList.remove('visible'); projectOpened=false; openedProject=null
  const stateQuat=quaternionForState(activeState), startQuat=cubeGroup.quaternion.clone()
  const bgS={angle:backgroundUniforms.uAngle.value,shiftX:backgroundUniforms.uShift.value.x,shiftY:backgroundUniforms.uShift.value.y}, bgT=backgroundState(activeState)
  const alignStart=performance.now(), alignDur=340
  function align(now){
    const r=Math.min((now-alignStart)/alignDur,1), t=easeInOutCubic(r); cubeGroup.quaternion.slerpQuaternions(startQuat,stateQuat,t); animateBackground(bgS,bgT,t); renderScene()
    if(r<1)return activeAnimationFrame=requestAnimationFrame(align)
    cubeGroup.quaternion.copy(stateQuat)
    const centerStart=performance.now(), centerDur=340
    function center(now2){
      const rr=Math.min((now2-centerStart)/centerDur,1), tt=easeInOutCubic(rr); camera.position.z=THREE.MathUtils.lerp(INNER_CAMERA_Z,0,tt); camera.rotation.y=THREE.MathUtils.lerp(Math.PI,0,tt); camera.fov=THREE.MathUtils.lerp(INNER_FOV,OUTER_FOV,tt); camera.updateProjectionMatrix(); cubeGroup.scale.setScalar(THREE.MathUtils.lerp(NORMAL_SCALE,FACE_SCALE,tt)); renderScene()
      if(rr<1)return activeAnimationFrame=requestAnimationFrame(center)
      camera.position.z=0; camera.rotation.y=0; camera.fov=responsiveOuterFov(); camera.updateProjectionMatrix(); cubeGroup.scale.setScalar(FACE_SCALE)
      const faceZ=HALF*FACE_SCALE, crossedZ=faceZ-.42, preZ=faceZ+.48
      const wallStart=performance.now(), wallDur=190
      function wall(now3){
        const rw=Math.min((now3-wallStart)/wallDur,1), tw=easeOutCubic(rw); camera.position.z=THREE.MathUtils.lerp(0,crossedZ,tw); renderScene()
        if(rw<1)return activeAnimationFrame=requestAnimationFrame(wall)
        innerLabels.forEach(label=>label.visible=false)
        const crossStart=performance.now(), crossDur=170; let fired=false
        function cross(now4){
          const rc=Math.min((now4-crossStart)/crossDur,1), tc=easeInOutCubic(rc); camera.position.z=THREE.MathUtils.lerp(crossedZ,preZ,tc); const strength=Math.max(0,1-Math.abs(rc-.48)/.50); setActiveFaceGlow(strength*.62); if(!fired&&rc>=.38){fired=true;fireMembrane('out')} renderScene()
          if(rc<1)return activeAnimationFrame=requestAnimationFrame(cross)
          setActiveFaceGlow(0); setCubeLabelMode('outer'); setOuterLabelsOpacity(0)
          const retreatStart=performance.now(), retreatDur=430
          function retreat(now5){
            const re=Math.min((now5-retreatStart)/retreatDur,1), te=easeInOutCubic(re); camera.position.z=THREE.MathUtils.lerp(preZ,10,te); setOuterLabelsOpacity(re<.24?0:(re-.24)/.76); renderScene()
            if(re<1)return activeAnimationFrame=requestAnimationFrame(retreat)
            camera.position.z=10; setOuterLabelsOpacity(1); insideSection=false; isAnimating=false; activeAnimationFrame=null; updateText(activeState); navButtons.forEach(b=>b.disabled=false); buildSectionChooser(); syncModeUi(); updateSectionIndexBadge(); showOpenFaceHint(); pulseInterfaceContent(); renderScene(); syncBrowserRoute()
            if (pendingOuterState != null) {
              const nextState = pendingOuterState
              pendingOuterState = null
              if (nextState !== activeState) requestAnimationFrame(() => animateToState(nextState))
            }
          }
          activeAnimationFrame=requestAnimationFrame(retreat)
        }
        activeAnimationFrame=requestAnimationFrame(cross)
      }
      activeAnimationFrame=requestAnimationFrame(wall)
    }
    activeAnimationFrame=requestAnimationFrame(center)
  }
  activeAnimationFrame=requestAnimationFrame(align)
}

const logoButton = document.querySelector('.logo')
if (logoButton) {
  logoButton.setAttribute('role', 'button')
  logoButton.setAttribute('tabindex', '0')
  logoButton.setAttribute('aria-label', 'На главную')
}

function goHome() {
  if (isAnimating) return
  if (insideSection) {
    pendingOuterState = 0
    exitSection()
    return
  }
  if (activeState !== 0) animateToState(0)
}

if (logoButton) {
  logoButton.addEventListener('click', () => { logoButton.classList.remove('logo-pulse'); void logoButton.offsetWidth; logoButton.classList.add('logo-pulse'); goHome() })
  logoButton.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault()
      goHome()
    }
  })
}

const cubeRaycaster = new THREE.Raycaster()
const cubePointer = new THREE.Vector2()
function faceIndexFromPointer(event) {
  const rect = canvas.getBoundingClientRect()
  cubePointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
  cubePointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1
  cubeRaycaster.setFromCamera(cubePointer, camera)
  const hits = cubeRaycaster.intersectObjects(faceMeshes, false)
  if (!hits.length) return -1
  return faceMeshes.indexOf(hits[0].object)
}

let outerSwipeStartX = 0
let outerSwipeStartY = 0
canvas.addEventListener('pointerdown', (event) => {
  if (event.pointerType !== 'touch' || insideSection || projectOpened) return
  outerSwipeStartX = event.clientX
  outerSwipeStartY = event.clientY
}, { passive: true })

canvas.addEventListener('pointerup', (event) => {
  if (event.button !== 0 || isAnimating || ignoreFaceClicks || projectOpened) return
  if (event.pointerType === 'touch' && !insideSection && outerSwipeStartX) {
    const dx = event.clientX - outerSwipeStartX
    const dy = event.clientY - outerSwipeStartY
    outerSwipeStartX = 0
    outerSwipeStartY = 0
    if (Math.abs(dx) >= 52 && Math.abs(dx) > Math.abs(dy) * 1.15) {
      const direction = dx < 0 ? 1 : -1
      const next = activeState === 0 ? (direction > 0 ? 1 : 6) : ((activeState - 1 + direction + 6) % 6) + 1
      animateToState(next)
      return
    }
  }

  // On the home intro a click is accepted only after the hypercube has stabilized.
  if (!insideSection && activeState === 0 && hyperBlend > 0.08) {
    hyperPointerOver = true
    setHyperStable(true)
    return
  }

  if (!insideSection) {
    const labelIndex = outerLabelIndexFromPointer(event)
    if (labelIndex >= 0) {
      const stateIndex = FACE_TO_STATE[labelIndex]
      if (stateIndex != null) {
        if (stateIndex === activeState && sectionSpaces[activeState]) enterSection(0)
        else animateToState(stateIndex)
      }
      return
    }
  }

  const faceIndex = faceIndexFromPointer(event)
  if (faceIndex < 0) return

  if (insideSection) {
    const innerIndex = FACE_TO_INNER_INDEX.get(faceIndex)
    if (innerIndex == null || !currentItems[innerIndex]) return
    rotateInside(innerIndex)
    return
  }

  const stateIndex = FACE_TO_STATE[faceIndex]
  if (stateIndex == null) return
  if (stateIndex === activeState && sectionSpaces[activeState]) enterSection(0)
  else animateToState(stateIndex)
})

canvas.addEventListener('pointermove', (event) => {
  if (!insideSection && activeState === 0 && !isAnimating) {
    const hyperHit = hyperFaceIndexFromPointer(event) >= 0
    const stableHit = hyperBlend <= 0.14 && (faceIndexFromPointer(event) >= 0 || outerLabelIndexFromPointer(event) >= 0)
    const hoveringIntroObject = hyperHit || stableHit
    if (hoveringIntroObject) {
      hyperPointerOver = true
      clearTimeout(hyperReturnTimer)
      hyperReturnTimer = null
      setHyperStable(true)
    } else if (hyperPointerOver) {
      hyperPointerOver = false
      scheduleHyperReturn()
    }
    if (hyperBlend > 0.14) {
      setOuterLabelHover(-1)
      canvas.style.cursor = hoveringIntroObject ? 'pointer' : 'default'
      return
    }
  }

  if (isAnimating) {
    setOuterLabelHover(-1)
    canvas.style.cursor = 'default'
    return
  }

  let faceIndex = -1
  if (!insideSection) {
    faceIndex = faceIndexFromPointer(event)
    const hoverIndex = faceIndex >= 0 && FACE_TO_STATE[faceIndex] != null ? faceIndex : -1
    setOuterLabelHover(hoverIndex)
    if (hoverIndex >= 0) {
      canvas.style.cursor = 'pointer'
      return
    }
  } else {
    setOuterLabelHover(-1)
  }

  if (faceIndex < 0) faceIndex = faceIndexFromPointer(event)
  if (faceIndex < 0) {
    canvas.style.cursor = 'default'
    return
  }
  if (insideSection) {
    const innerIndex = FACE_TO_INNER_INDEX.get(faceIndex)
    canvas.style.cursor = innerIndex != null && currentItems[innerIndex] ? 'pointer' : 'default'
    return
  }
  canvas.style.cursor = FACE_TO_STATE[faceIndex] != null ? 'pointer' : 'default'
}, { passive: true })

canvas.addEventListener('pointerleave', () => {
  setOuterLabelHover(-1)
  canvas.style.cursor = 'default'
  if (!insideSection && activeState === 0) {
    hyperPointerOver = false
    scheduleHyperReturn()
  }
}, { passive: true })

canvas.addEventListener('pointermove', (event) => {
  updateFlashlightFromPointer(event)
}, { passive: true })

canvas.addEventListener('pointerleave', () => {
  clearFlashlightPointer()
}, { passive: true })


function escapeMediaText(value = '') {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[char]))
}

function projectCaseMediaMarkup(path, title = '', className = '') {
  const src = String(path || '')
  const safeTitle = escapeMediaText(title)
  const safeSrc = escapeMediaText(src)
  if (!src) return `<div class="project-media-fallback"><span>MEDIA</span><strong>Файл не выбран</strong></div>`
  if (/\.(mp4|webm)(?:\?|#|$)/i.test(src)) {
    return `<video class="${className}" src="${safeSrc}" autoplay muted loop playsinline preload="metadata" aria-label="${safeTitle}"></video>`
  }
  return `<img class="${className}" src="${safeSrc}" alt="${safeTitle}" loading="eager" decoding="async">`
}

function projectCardMediaMarkup(item) {
  const project = item?.[5] || {}
  const media = normalizedProjectMedia(project)
  const cover = media.find((entry) => entry.cover) || media[0]
  const src = cover?.src || item?.[1] || ''
  return projectCaseMediaMarkup(src, item?.[0] || '', 'project-card__asset')
}

function projectMediaItems(item = openedProject) {
  return normalizedProjectMedia(item?.[5] || {})
}

function projectImagePath(item) {
  const media = projectMediaItems(item)
  const image = media.find((entry) => entry.type !== 'video')
  if (image?.src) return image.src
  return item && typeof item[1] === 'string' && !/\.(mp4|webm)(?:\?|#|$)/i.test(item[1]) ? item[1] : ''
}

function preloadMediaEntry(entry) {
  if (!entry?.src) return
  if (entry.type === 'video') {
    const video = document.createElement('video')
    video.preload = 'metadata'
    video.src = entry.src
    return
  }
  const image = new Image()
  image.decoding = 'async'
  image.src = entry.src
}

function preloadProjectMediaNeighbors() {
  const media = projectMediaItems()
  if (media.length > 1) {
    const index = Math.max(0, Math.min(openedProjectMediaIndex, media.length - 1))
    preloadMediaEntry(media[(index - 1 + media.length) % media.length])
    preloadMediaEntry(media[(index + 1) % media.length])
  }
}

function preloadProjectNeighbors() {
  if (!projectOpened || currentSection?.key !== 'projects') return
  const list = projectPortfolio[activeInnerIndex] || []
  if (list.length < 2) return
  const index = Math.max(0, openedProjectIndex)
  const candidates = [list[(index - 1 + list.length) % list.length], list[(index + 1) % list.length]]
  candidates.forEach((candidate) => preloadMediaEntry(projectMediaItems(candidate)[0] || { src: projectImagePath(candidate), type: 'image' }))
}

function updateCaseNavigationMeta() {
  if (!projectOpened || currentSection?.key !== 'projects') return
  const list = projectPortfolio[activeInnerIndex] || []
  if (!list.length) return
  const index = Math.max(0, openedProjectIndex)
  const prev = list[(index - 1 + list.length) % list.length]
  const next = list[(index + 1) % list.length]
  const prevTitle = casePrevButton.querySelector('strong')
  const nextTitle = caseNextButton.querySelector('strong')
  if (prevTitle) prevTitle.textContent = prev?.[0] || ''
  if (nextTitle) nextTitle.textContent = next?.[0] || ''
}

function bindCaseMediaUi() {
  const mediaBox = projectCase.querySelector('.project-case__media')
  if (!mediaBox) return
  mediaBox.querySelectorAll('[data-media-dir]').forEach((button) => {
    button.addEventListener('pointerdown', (event) => event.stopPropagation())
    button.addEventListener('click', (event) => {
      event.preventDefault()
      event.stopPropagation()
      switchProjectMedia(Number(button.dataset.mediaDir || 0))
    })
  })
  const asset = mediaBox.querySelector('img,video')
  if (asset) asset.addEventListener('error', () => {
    const fallback = document.createElement('div')
    fallback.className = 'project-media-fallback'
    fallback.innerHTML = '<span>MEDIA</span><strong>Не удалось загрузить файл</strong>'
    asset.replaceWith(fallback)
  }, { once: true })

  let touchStartX = 0
  let touchStartY = 0
  mediaBox.addEventListener('pointerdown', (event) => {
    if (event.pointerType === 'mouse') return
    touchStartX = event.clientX
    touchStartY = event.clientY
  }, { passive: true })
  mediaBox.addEventListener('pointerup', (event) => {
    if (event.pointerType === 'mouse' || !touchStartX) return
    const dx = event.clientX - touchStartX
    const dy = event.clientY - touchStartY
    touchStartX = 0
    touchStartY = 0
    if (Math.abs(dx) < 44 || Math.abs(dx) < Math.abs(dy) * 1.15) return
    switchProjectMedia(dx < 0 ? 1 : -1)
  }, { passive: true })
}

function renderOpenedProjectCase(item) {
  if (!item) return
  applyCurrentTypography()
  const caseData = item[5] || {}
  const media = projectMediaItems(item)
  openedProjectMediaIndex = Math.max(0, Math.min(openedProjectMediaIndex, Math.max(0, media.length - 1)))
  const currentMedia = media[openedProjectMediaIndex] || { src: item[1] || '', type: /\.(mp4|webm)(?:\?|#|$)/i.test(item[1] || '') ? 'video' : 'image' }
  const mediaNav = media.length > 1 ? `<button type="button" class="project-case__media-prev" data-media-dir="-1" aria-label="Предыдущее медиа">←</button><button type="button" class="project-case__media-next" data-media-dir="1" aria-label="Следующее медиа">→</button><div class="project-case__media-counter">${String(openedProjectMediaIndex + 1).padStart(2,'0')} / ${String(media.length).padStart(2,'0')}</div>` : ''
  projectCase.innerHTML = `<div class="project-case__media" data-admin-media-target>${projectCaseMediaMarkup(currentMedia.src, currentMedia.alt || item[0])}${mediaNav}</div><div class="project-case__counter">CASE ${String(openedProjectIndex + 1).padStart(2,'0')} / ${String((projectPortfolio[activeInnerIndex] || []).length).padStart(2,'0')}</div><div class="project-case__info"><span>4ДКУБ / CASE</span><h2 data-case-field="title">${item[0]}</h2><p><b>КЛИЕНТ</b><br><span data-case-field="client">${caseData.client || '—'}</span></p><p><b>ЗАДАЧА</b><br><span data-case-field="task">${caseData.task || item[2] || 'Описание проекта будет добавлено.'}</span></p><p><b>РЕШЕНИЕ</b><br><span data-case-field="solution">${caseData.solution || 'Дизайн и цифровая система.'}</span></p><p><b>РЕАЛИЗАЦИЯ</b><br><span data-case-field="implementation">${caseData.implementation || 'Разработка и запуск проекта.'}</span></p><p><b>ТЕХНОЛОГИИ</b><br><span data-case-field="technologies">${Array.isArray(caseData.technologies) ? caseData.technologies.join(' / ') : ''}</span></p><p><b>CTA</b><br><span data-case-field="ctaText">${caseData.ctaText || ''}</span></p><button type="button" class="project-case__share">↗ SHARE</button></div>`
  projectCase.classList.add('visible')
  syncCompositionMode()
  bindCaseMediaUi()
  const shareButton = projectCase.querySelector('.project-case__share')
  if (shareButton) shareButton.addEventListener('click', async () => {
    const url = location.href
    try {
      if (navigator.share) await navigator.share({ title: openedProject?.[0] || document.title, url })
      else { await navigator.clipboard.writeText(url); shareButton.textContent = 'ССЫЛКА СКОПИРОВАНА'; setTimeout(() => { if (shareButton.isConnected) shareButton.textContent = '↗ SHARE' }, 1600) }
    } catch (_) {}
  })
  syncOverlayToActiveFace(projectCase, 0.03)
  updateCaseNavigationMeta()
  preloadProjectMediaNeighbors()
  preloadProjectNeighbors()
  pulseInterfaceContent()
  document.dispatchEvent(new CustomEvent('cube4d:casechange'))
  syncBrowserRoute()
}

function renderCaseMediaOnly() {
  if (!projectOpened) return
  const media = projectMediaItems()
  const mediaBox = projectCase.querySelector('.project-case__media')
  if (!mediaBox) return renderOpenedProjectCase(openedProject)
  openedProjectMediaIndex = Math.max(0, Math.min(openedProjectMediaIndex, Math.max(0, media.length - 1)))
  const currentMedia = media[openedProjectMediaIndex] || { src: openedProject[1] || '' }
  const mediaNav = media.length > 1 ? `<button type="button" class="project-case__media-prev" data-media-dir="-1" aria-label="Предыдущее медиа">←</button><button type="button" class="project-case__media-next" data-media-dir="1" aria-label="Следующее медиа">→</button><div class="project-case__media-counter">${String(openedProjectMediaIndex + 1).padStart(2,'0')} / ${String(media.length).padStart(2,'0')}</div>` : ''
  mediaBox.classList.remove('media-swap')
  mediaBox.innerHTML = `${projectCaseMediaMarkup(currentMedia.src, currentMedia.alt || openedProject[0])}${mediaNav}`
  void mediaBox.offsetWidth
  mediaBox.classList.add('media-swap')
  bindCaseMediaUi()
  preloadProjectMediaNeighbors()
}

function switchProjectMedia(delta) {
  if (!projectOpened || isAnimating) return
  const media = projectMediaItems()
  if (media.length < 2) return
  openedProjectMediaIndex = (openedProjectMediaIndex + delta + media.length) % media.length
  renderCaseMediaOnly()
}

function switchProjectCase(delta) {
  if (!projectOpened || !currentSection || currentSection.key !== 'projects' || isAnimating) return
  const list = projectPortfolio[activeInnerIndex] || []
  if (!list.length) return
  if (openedProjectIndex < 0) openedProjectIndex = Math.max(0, list.indexOf(openedProject))
  openedProjectIndex = (openedProjectIndex + delta + list.length) % list.length
  openedProject = list[openedProjectIndex]
  openedProjectMediaIndex = 0
  renderOpenedProjectCase(openedProject)
}

function bindCaseNavButton(button, delta) {
  button.addEventListener('pointerdown', (event) => event.stopPropagation())
  button.addEventListener('pointerup', (event) => event.stopPropagation())
  button.addEventListener('click', (event) => {
    event.preventDefault()
    event.stopPropagation()
    switchProjectCase(delta)
  })
}
bindCaseNavButton(casePrevButton, -1)
bindCaseNavButton(caseNextButton, 1)

innerBackButton.addEventListener('click', () => {
  if (projectOpened) { projectOpened=false; openedProject=null; openedProjectIndex=-1; openedProjectMediaIndex=0; projectCase.classList.remove('visible'); innerUiNav.classList.remove('case-open'); syncCompositionMode(); renderProjectGallery(); document.dispatchEvent(new CustomEvent('cube4d:casechange')); syncBrowserRoute(); return }
  exitSection()
})
cubeExitButton.addEventListener('click', () => {
  innerBackButton.click()
})
openFaceHint.addEventListener('click', () => { if (!insideSection && activeState !== 0 && sectionSpaces[activeState]) enterSection(0) })
navButtons.forEach((button) => {
  button.addEventListener('pointerenter', () => {
    if (!insideSection && activeState === 0 && !isAnimating) {
      hyperPointerOver = true
      setHyperStable(true)
    }
  })
  button.addEventListener('pointerleave', () => {
    if (!insideSection && activeState === 0 && !isAnimating) {
      hyperPointerOver = false
      scheduleHyperReturn()
    }
  })
  button.addEventListener('click', () => animateToState(Number(button.dataset.state)))
})


window.addEventListener('keydown', (event) => {
  if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.altKey) return
  const target = event.target
  if (target && (target.matches?.('input, textarea, select') || target.isContentEditable)) return
  if (isAnimating) return

  if (event.key === 'Escape') {
    if (projectOpened) {
      innerBackButton.click()
    } else if (insideSection) {
      exitSection()
    }
    return
  }

  if (projectOpened && (event.key === 'ArrowLeft' || event.key === 'ArrowRight')) {
    event.preventDefault()
    switchProjectCase(event.key === 'ArrowLeft' ? -1 : 1)
    return
  }

  if (!insideSection && (event.key === 'ArrowLeft' || event.key === 'ArrowRight')) {
    event.preventDefault()
    const direction = event.key === 'ArrowRight' ? 1 : -1
    const next = activeState === 0 ? (direction > 0 ? 1 : 6) : ((activeState - 1 + direction + 6) % 6) + 1
    animateToState(next)
    return
  }

  if (!insideSection && event.key === 'Enter' && activeState !== 0 && sectionSpaces[activeState]) {
    event.preventDefault()
    enterSection(0)
  }
})

window.addEventListener('pointermove', (event) => {
  if (prefersReducedMotion || window.innerWidth <= 720) return
  const x = (event.clientX / window.innerWidth - 0.5) * 2
  const y = (event.clientY / window.innerHeight - 0.5) * 2
  ambientParallax.style.setProperty('--px', `${x * 10}px`)
  ambientParallax.style.setProperty('--py', `${y * 8}px`)
}, { passive: true })

function adaptivePixelRatio() {
  const memory = Number(navigator.deviceMemory || 4)
  const cores = Number(navigator.hardwareConcurrency || 4)
  const mobile = window.innerWidth <= 720
  const weak = memory <= 2 || cores <= 4
  const cap = mobile ? (weak ? 1 : 1.15) : (weak ? 1.15 : 1.6)
  return Math.min(window.devicePixelRatio || 1, cap)
}

function applyRendererQuality() {
  renderer.setPixelRatio(adaptivePixelRatio())
}

applyRendererQuality()
window.addEventListener('resize',()=>{ camera.aspect=window.innerWidth/window.innerHeight; applyRendererQuality(); renderer.setSize(window.innerWidth,window.innerHeight,false); backgroundUniforms.uAspect.value=window.innerWidth/window.innerHeight; applyResponsiveSceneScale(); renderScene(); syncProjectGalleryToFace(); syncOverlayToActiveFace(serviceDetail, 0.105); if (projectOpened) syncOverlayToActiveFace(projectCase, 0.03) },{passive:true})
applyResponsiveSceneScale()
document.addEventListener('visibilitychange',()=>{ if(document.visibilityState==='visible')renderScene() })


// === V10.4 SITE DESIGN SETTINGS ===
const SITE_FONT_PRESETS = [
  ['Arial', 'Arial, Helvetica, sans-serif', ''],
  ['Inter', 'Inter, Arial, sans-serif', 'Inter:wght@300;400;500;600;700;800'],
  ['Manrope', 'Manrope, Arial, sans-serif', 'Manrope:wght@300;400;500;600;700;800'],
  ['Montserrat', 'Montserrat, Arial, sans-serif', 'Montserrat:wght@300;400;500;600;700;800'],
  ['Roboto', 'Roboto, Arial, sans-serif', 'Roboto:wght@300;400;500;700;900'],
  ['Rubik', 'Rubik, Arial, sans-serif', 'Rubik:wght@300;400;500;600;700;800;900'],
  ['IBM Plex Sans', '"IBM Plex Sans", Arial, sans-serif', 'IBM+Plex+Sans:wght@300;400;500;600;700'],
  ['Fira Sans', '"Fira Sans", Arial, sans-serif', 'Fira+Sans:wght@300;400;500;600;700;800'],
  ['Noto Sans', '"Noto Sans", Arial, sans-serif', 'Noto+Sans:wght@300;400;500;600;700;800'],
  ['Noto Serif', '"Noto Serif", Georgia, serif', 'Noto+Serif:wght@300;400;500;600;700;800'],
  ['PT Sans', '"PT Sans", Arial, sans-serif', 'PT+Sans:wght@400;700'],
  ['PT Serif', '"PT Serif", Georgia, serif', 'PT+Serif:wght@400;700'],
  ['Golos Text', '"Golos Text", Arial, sans-serif', 'Golos+Text:wght@400;500;600;700;800;900'],
  ['Commissioner', 'Commissioner, Arial, sans-serif', 'Commissioner:wght@300;400;500;600;700;800'],
  ['Onest', 'Onest, Arial, sans-serif', 'Onest:wght@300;400;500;600;700;800;900'],
  ['Geologica', 'Geologica, Arial, sans-serif', 'Geologica:wght@300;400;500;600;700;800;900'],
  ['Sofia Sans', '"Sofia Sans", Arial, sans-serif', 'Sofia+Sans:wght@300;400;500;600;700;800;900'],
  ['Unbounded', 'Unbounded, Arial, sans-serif', 'Unbounded:wght@300;400;500;600;700;800;900'],
  ['Russo One', '"Russo One", Arial, sans-serif', 'Russo+One'],
  ['Comfortaa', 'Comfortaa, Arial, sans-serif', 'Comfortaa:wght@300;400;500;600;700'],
  ['Poiret One', '"Poiret One", Arial, sans-serif', 'Poiret+One'],
  ['Playfair Display', '"Playfair Display", Georgia, serif', 'Playfair+Display:wght@400;500;600;700;800;900'],
  ['Cormorant Garamond', '"Cormorant Garamond", Georgia, serif', 'Cormorant+Garamond:wght@300;400;500;600;700'],
  ['Prata', 'Prata, Georgia, serif', 'Prata'],
  ['Tenor Sans', '"Tenor Sans", Arial, sans-serif', 'Tenor+Sans'],
  ['Forum', 'Forum, Georgia, serif', 'Forum'],
  ['Yeseva One', '"Yeseva One", Georgia, serif', 'Yeseva+One'],
  ['Kelly Slab', '"Kelly Slab", Arial, sans-serif', 'Kelly+Slab'],
  ['Neucha', 'Neucha, Arial, sans-serif', 'Neucha'],
  ['Oswald', 'Oswald, Arial, sans-serif', 'Oswald:wght@300;400;500;600;700'],
  ['Ubuntu', 'Ubuntu, Arial, sans-serif', 'Ubuntu:wght@300;400;500;700'],
  ['Raleway', 'Raleway, Arial, sans-serif', 'Raleway:wght@300;400;500;600;700;800;900'],
  ['Yanone Kaffeesatz', '"Yanone Kaffeesatz", Arial, sans-serif', 'Yanone+Kaffeesatz:wght@300;400;500;600;700']
]

function ensureGoogleFont(fontName) {
  const preset = SITE_FONT_PRESETS.find((item) => item[0] === fontName)
  if (!preset || !preset[2]) return
  const id = `cube4d-font-${fontName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`
  if (document.getElementById(id)) return
  const link = document.createElement('link')
  link.id = id
  link.rel = 'stylesheet'
  link.href = `https://fonts.googleapis.com/css2?family=${preset[2]}&display=swap`
  document.head.appendChild(link)
}

function fontStack(fontName) {
  const preset = SITE_FONT_PRESETS.find((item) => item[0] === fontName)
  return preset ? preset[1] : 'Arial, Helvetica, sans-serif'
}

async function refreshCubeLabelFonts(fontName) {
  const selected = String(fontName || 'Arial')
  ensureGoogleFont(selected)
  cubeLabelFontFamily = fontStack(selected)
  try {
    if (document.fonts && document.fonts.load) {
      await document.fonts.load(`700 55px ${cubeLabelFontFamily}`)
      await document.fonts.ready
    }
  } catch (_) {}

  outerFaceLabels.forEach((label, index) => {
    const face = faces[index]
    if (!face || !label.material) return
    if (label.material.map) label.material.map.dispose()
    label.material.map = makeLabelTexture(face.number, face.title, index === hoveredOuterLabelIndex)
    label.material.needsUpdate = true
  })

  if (currentSection) {
    const items = normalizedItems(currentSection)
    innerLabels.forEach((label, index) => {
      if (label.material.map) label.material.map.dispose()
      if (index < items.length) label.material.map = makeInnerTexture(items[index], currentSection.title)
      label.material.needsUpdate = true
    })
  }
  renderScene()
}

function applyLiveVisualSettings(settings = {}) {
  const mainFont = String(settings.mainFont || 'Arial')
  const headingFont = String(settings.headingFont || mainFont)
  const uiFont = String(settings.uiFont || mainFont)
  ;[mainFont, headingFont, uiFont].forEach(ensureGoogleFont)
  document.documentElement.style.setProperty('--font-main', fontStack(mainFont))
  document.documentElement.style.setProperty('--font-heading', fontStack(headingFont))
  document.documentElement.style.setProperty('--font-ui', fontStack(uiFont))
  refreshCubeLabelFonts(uiFont)
  const bgIntensity = THREE.MathUtils.clamp(Number(settings.backgroundIntensity ?? 1), 0.35, 1.8)
  backgroundUniforms.uIntensity.value = bgIntensity
  const cubeOpacity = THREE.MathUtils.clamp(Number(settings.cubeOpacity ?? FACE_OPACITY), 0.03, 0.65)
  faceMeshes.forEach((mesh) => { mesh.material.opacity = cubeOpacity })
  hyperSpeedMultiplier = THREE.MathUtils.clamp(Number(settings.hyperSpeed ?? 1), 0.05, 3)
  renderScene()
}

// Live admin was removed in v10.4. The public site only consumes settings saved by /admin/.

window.addEventListener('message', (event) => {
  if (event.origin !== window.location.origin) return
  const payload = event.data
  if (!payload || payload.type !== 'cube4d-admin-preview' || !payload.settings) return
  if (!cmsContentRaw) cmsContentRaw = { states: [], sections: {}, settings: {} }
  cmsContentRaw.settings = { ...(cmsContentRaw.settings || {}), ...payload.settings }
  applyLiveVisualSettings(cmsContentRaw.settings)
  applyCurrentTypography(cmsContentRaw.settings)
  if (Number.isFinite(Number(payload.settings.backgroundTheme))) {
    backgroundUniforms.uTheme.value = Number(payload.settings.backgroundTheme)
    renderScene()
  }
})

renderScene()
