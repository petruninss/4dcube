The six original Radiant effect files are vendored here by:
  npm run sync:radiant

Production build runs that sync automatically before Vite build.
After build, the site loads these files locally from /radiant/ and has no Radiant runtime CDN dependency.
Source: https://github.com/pbakaus/radiant (MIT License)
